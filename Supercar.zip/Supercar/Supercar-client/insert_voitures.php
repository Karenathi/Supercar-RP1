<?php
include('php/config.php'); // Connexion à la base de données

$folder = 'assets/list/';
$images = scandir($folder);

$insertedModels = []; // Pour éviter les doublons de modèles

foreach ($images as $img) {
    if (in_array(pathinfo($img, PATHINFO_EXTENSION), ['jpg', 'jpeg', 'png'])) {
        // Extraire le nom du modèle (sans les suffixes _1, _2, etc.)
        $modelName = preg_replace('/(_\d+)?\.(jpg|jpeg|png)$/i', '', $img);

        if (!isset($insertedModels[$modelName])) {
            $insertedModels[$modelName] = true;

            // Données aléatoires réalistes
            $transmissions = ['Automatic', 'Manual'];
            $carburants = ['Gasoline', 'Diesel', 'Hybrid', 'Electric'];

            $transmission = $transmissions[array_rand($transmissions)];
            $carburant = $carburants[array_rand($carburants)];
            $annee = rand(2015, 2023);
            $km = rand(5000, 120000);
            $prix = rand(30000, 150000);
            $engine = number_format(rand(10, 40) / 10, 1); // ex: 1.6, 2.0, etc.

            // Préparer l'insertion
            $stmt = $pdo->prepare("
                INSERT INTO voitures 
                (car_name, car_ref, car_image, car_status, car_transmission, fuel_type, engine_capacity, year, car_km, car_price)
                VALUES 
                (:car_name, :car_ref, :car_image, 'Available', :transmission, :fuel, :engine, :year, :km, :price)
            ");

            $stmt->execute([
                'car_name' => $modelName,
                'car_ref' => strtoupper(substr($modelName, 0, 3)) . '-' . rand(100, 999),
                'car_image' => $folder . $img,
                'transmission' => $transmission,
                'fuel' => $carburant,
                'engine' => $engine,
                'year' => $annee,
                'km' => $km,
                'price' => $prix,
            ]);

            echo "✅ Modèle inséré : $modelName<br>";
        }
    }
}
?>
