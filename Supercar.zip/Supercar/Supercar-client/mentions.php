<!-- mentions.php -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Mentions légales - Supercar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <!-- Bouton pour ouvrir la modale -->
    <footer class="text-center mt-5">
        <a href="#" data-bs-toggle="modal" data-bs-target="#mentionsModal">Mentions légales</a>
    </footer>

    <!-- Modale Bootstrap -->
    <div class="modal fade" id="mentionsModal" tabindex="-1" aria-labelledby="mentionsLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="mentionsLabel">Mentions légales – Supercar</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
          </div>
          <div class="modal-body">
            <p><strong>Nom du site :</strong> Supercar</p>
            <p><strong>URL :</strong> http://localhost/supercar</p>
            <p><strong>Responsables du projet :</strong><br>
            Karen [Ton Nom] & Dimitri MEYEPA<br>
            Étudiants en BTS SIO – Réalisation Professionnelle<br>
            [Nom de l’établissement]<br>
            [Adresse de l’établissement]<br>
            Email : contact@supercar-projet.com</p>

            <p><strong>Hébergement :</strong><br>
            Site hébergé localement via MAMP dans le cadre d’un projet scolaire. Aucune donnée personnelle n’est collectée à des fins commerciales.</p>

            <p><strong>Propriété intellectuelle :</strong><br>
            Le contenu de ce site est protégé. Toute reproduction est interdite sans autorisation des auteurs.</p>

            <p><strong>Données personnelles :</strong><br>
            Aucune donnée personnelle n’est collectée sur ce site.</p>

            <p><strong>Limitation de responsabilité :</strong><br>
            Ce site est un prototype académique. Il ne représente pas une entreprise réelle.</p>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
          </div>
        </div>
      </div>
    </div>

    <!-- JS Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
