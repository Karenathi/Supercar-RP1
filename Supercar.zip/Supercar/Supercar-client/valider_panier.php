<?php
session_start();
include('config.php'); 



if (!isset($_SESSION['panier_essai']) || empty($_SESSION['panier_essai'])) {
    echo "<script>alert('Le panier est vide.'); window.location.href='panier.php';</script>";
    exit();
}

if (!isset($_SESSION['client_id'])) {
    echo "<script>alert('Vous devez être connecté pour valider le panier.'); window.location.href='connexion.php';</script>";
    exit();
}

$client_id = $_SESSION['client_id'];

try {
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    foreach ($_SESSION['panier_essai'] as $index => $essai) {

        if (empty($essai['carReference'])) continue;

        // Conversion date
        $rawDate = str_replace('T', ' ', $essai['testDate']);
        $date = DateTime::createFromFormat('Y-m-d H:i', $rawDate);
        if (!$date) $date = DateTime::createFromFormat('Y-m-d H:i:s', $rawDate);
        if (!$date) continue;

        $formattedDate = $date->format('Y-m-d H:i:s');

        // Vérifie doublon
        $check = $pdo->prepare("SELECT COUNT(*) FROM essai 
            WHERE id_client=:id_client 
            AND car_name=:car_name 
            AND date_essai=:date_essai");
        $check->execute([
            ':id_client' => $client_id,
            ':car_name' => $essai['carReference'],
            ':date_essai' => $formattedDate
        ]);

        if ($check->fetchColumn() > 0) continue;

        // Insert
        $stmt = $pdo->prepare("INSERT INTO essai 
            (date_essai, statut, car_name, id_client) 
            VALUES (:date_essai, 'en_cours', :car_name, :id_client)");
        $stmt->execute([
            ':date_essai' => $formattedDate,
            ':car_name' => $essai['carReference'],
            ':id_client' => $client_id
        ]);
    }

    // Vide le panier
    $_SESSION['panier_essai'] = [];

    echo "<script>alert('✅ Toutes les demandes du panier ont été validées !'); window.location.href='panier.php';</script>";
    exit();

} catch (Exception $e) {
    echo "<script>alert('❌ Erreur : " . addslashes($e->getMessage()) . "'); window.location.href='panier.php';</script>";
    exit();
}
?>
