<?php
include('navbar.php');
include('config.php');


$query_carousel = "SELECT * FROM carousel WHERE status = 1";
$stmt_carousel = $pdo->prepare($query_carousel);
$stmt_carousel->execute();
$carousels = $stmt_carousel->fetchAll(PDO::FETCH_ASSOC);


$query_about = "SELECT * FROM home_about LIMIT 1";
$stmt_about = $pdo->prepare($query_about);
$stmt_about->execute();
$about = $stmt_about->fetch(PDO::FETCH_ASSOC);

$query_stats = "SELECT * FROM home_stat";
$stmt_stats = $pdo->prepare($query_stats);
$stmt_stats->execute();
$stats = $stmt_stats->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Accueil - Supercar</title>
</head>

<!-- Carousel Start -->
<div class="container-fluid p-0 mb-5">
   <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner">
        <?php
        $isActive = true; 
        foreach ($carousels as $carousel) {
            $activeClass = $isActive ? 'active' : ''; // Ajouter la classe "active" à la première image
            $isActive = false; // Après la première itération, la classe "active" ne sera plus ajoutée
            echo '<div class="carousel-item ' . $activeClass . '" style="height: 400px; background-image: url(\'' . $carousel['background_image'] . '\');">';
            echo '    <div class="carousel-caption d-flex align-items-center">';
            echo '        <div class="container">';
            echo '            <div class="row align-items-center justify-content-center justify-content-lg-start">';
            echo '                <div class="col-10 col-lg-7 text-center text-lg-start">';
            echo '                    <h6 class="text-white text-uppercase mb-3 animated slideInDown">' . $carousel['title'] . '</h6>';
            echo '                    <h1 class="display-3 text-white mb-4 pb-3 animated slideInDown">' . $carousel['subtitle'] . '</h1>';
            echo '                </div>';
            echo '                <div class="col-lg-5 d-none d-lg-flex animated zoomIn">';
            echo '                    <img class="img-fluid" src="' . $carousel['image'] . '" alt="">';
            echo '                </div>';
            echo '            </div>';
            echo '        </div>';
            echo '    </div>';
            echo '</div>';
        }
        ?>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Précédent</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Suivant</span>
    </button>
  </div>
</div>
<!-- Carousel End -->





<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 pt-4" style="min-height: 400px;">
                <div class="position-relative h-100 wow fadeIn" data-wow-delay="0.1s">
                    <img class="position-absolute img-fluid w-100 h-100" src="<?php echo $about['image']; ?>" style="object-fit: cover;" alt="">
                    <div class="position-absolute top-0 end-0 mt-n4 me-n4 py-4 px-5" style="background: rgba(0, 0, 0, .08);">
                        <h1 class="display-4 text-white mb-0"><?php echo $about['experience_years']; ?> <span class="fs-4">Ans</span></h1>
                        <h4 class="text-white"><?php echo $about['experience_text']; ?></h4>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <h6 class="text-primary text-uppercase">À Propos de Nous</h6>
                <h1 class="mb-4"><span class="text-primary">Supercar</span> <?php echo $about['subtitle']; ?></h1>
                <p class="mb-4"><?php echo $about['description']; ?></p>
                <h4 class="text-primary mb-4">Newsletter</h4>
                <p>Recevez les dernières offres et nouveautés de SuperCar.</p>
                <div class="position-relative ms-1" style="max-width: 400px;">
                    <input class="form-control border-1 w-100 py-3 ps-4 pe-5" type="email" placeholder="Votre email">
                    <button type="button" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2" onclick="submitNewsletter()">S'inscrire</button>
            </div>
        </div>
    </div>
  </div>
</div>


<script>
    function submitNewsletter() {
        let emailInput = document.querySelector('.form-control');
        let email = emailInput.value.trim();

        if (email === "") {
            alert("Veuillez entrer une adresse email !");
        } else {
            alert("Email bien reçu ! Merci de vous être inscrit(e).");
            emailInput.value = ""; 
        }
    }
</script>
<!-- About End -->

<!-- Service Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">
            <?php
            $query = "SELECT * FROM home_services";
            $stmt = $pdo->prepare($query);
            $stmt->execute();
            $services = $stmt->fetchAll(PDO::FETCH_ASSOC);
            foreach ($services as $row) {
                echo '<div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">';
                echo '    <div class="d-flex py-5 px-4">';
               
                echo '        <i class="fa ' . $row['icon'] . ' fa-3x text-primary flex-shrink-0"></i>'; 
                echo '        <div class="ps-4">';
                echo '            <h5 class="mb-3">' . $row['title'] . '</h5>';
                echo '            <p>' . $row['description'] . '</p>';
                echo '        </div>';
                echo '    </div>';
                echo '</div>';
            }
            ?>
        </div>
    </div>
</div>
<!-- Service End -->

<!-- Fact Start -->
<div class="container-fluid fact bg-dark my-5 py-5">
    <div class="container-fluid">
        <div class="row g-4">
            <?php foreach ($stats as $stat) { ?>
                <div class="col-md-6 col-lg-3 text-center wow fadeIn" data-wow-delay="0.1s">
                    <i class="fa <?php echo $stat['icon']; ?> fa-2x text-white mb-3"></i>
                    <h2 class="text-white mb-2" data-toggle="counter-up"><?php echo $stat['value']; ?></h2>
                    <p class="text-white mb-0"><?php echo $stat['title']; ?></p>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<!-- Fact End -->


<?php include('footer.php'); ?>
</body>
</html>