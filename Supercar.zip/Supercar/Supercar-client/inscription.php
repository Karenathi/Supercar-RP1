<?php
session_start();
include('config.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupération des données du formulaire
    $nom = htmlspecialchars($_POST['nom']);
    $prenom = htmlspecialchars($_POST['prenom']);
    $email = htmlspecialchars($_POST['email']);
    $telephone = htmlspecialchars($_POST['telephone']);
    $adresse = htmlspecialchars($_POST['adresse']);
    $password = $_POST['password'];

    // Vérification si l'email existe déjà
    $checkQuery = "SELECT * FROM client WHERE email_client = :email";
    $stmt = $pdo->prepare($checkQuery);
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "❌ Cet email est déjà utilisé. Veuillez en choisir un autre.";
        exit;
    }

    // Hash du mot de passe
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Requête d'insertion
    $query = "INSERT INTO client (nom_client, prenom_client, email_client, telephone_client, adresse_client, password_client) 
              VALUES (:nom, :prenom, :email, :telephone, :adresse, :password)";

    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':nom', $nom);
    $stmt->bindParam(':prenom', $prenom);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':telephone', $telephone);
    $stmt->bindParam(':adresse', $adresse);
    $stmt->bindParam(':password', $hashed_password);

    if ($stmt->execute()) {
        // Connexion automatique
        $_SESSION['client_id'] = $pdo->lastInsertId();
        $_SESSION['client_nom'] = $nom;
        $_SESSION['client_prenom'] = $prenom;

        echo "<script>
            alert('✅ Inscription réussie !');
            window.location.href = 'index.php'; 
        </script>";
        exit;
    } else {
        echo "❌ Une erreur est survenue lors de l'inscription.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion Supercar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="img/favicon.ico" rel="icon">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        h1 {
            color: white;
        }
        .form-control {
            border-radius: 5px;
            border: white solid 1px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.13);
        }
        body {
            background-color: #f8f9fa;
        }
        .login-container {
            max-width: 1200px;
            margin: auto;
            margin-top: 50px;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .left-panel {
            padding: 50px;
        }
        .right-panel {
            background: url('assets/list/right-pannel.png') no-repeat center/cover;
            color: white;
            padding: 50px;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            position: relative;
        }
        .right-panel::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(183, 28, 28, 0.67);
        }
        .right-panel * {
            position: relative;
            z-index: 1;
        }
        .btn-custom {
            background-color: #d32f2f;
            color: white;
            border: none;
            border-radius: 5px;
        }
        .btn-custom:hover {
            background-color: #b71c1c;
            color: white;
        }
        .social-icons a {
            margin: 0 5px;
            color: #d32f2f;
            font-size: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row login-container">
        <!-- Panneau gauche -->
        <div class="col-md-6 left-panel">
            <div class="text-center">
                <img src="assets/logo1.png" alt="" style="width: 10rem; margin-bottom:2rem;">
                <p class="text-muted">Inscrivez-vous pour accéder à l'univers des supercars de haute performance.</p>
            </div>
            <form action="inscription.php" method="POST">
                <div class="mb-3">
                    <input type="text" name="nom" class="form-control" placeholder="Nom" required>
                </div>
                <div class="mb-3">
                    <input type="text" name="prenom" class="form-control" placeholder="Prénom" required>
                </div>
                <div class="mb-3">
                    <input type="email" name="email" class="form-control" placeholder="Email" required>
                </div>
                <div class="mb-3">
                    <input type="text" name="telephone" class="form-control" placeholder="Téléphone" required>
                </div>
                <div class="mb-3">
                    <input type="text" name="adresse" class="form-control" placeholder="Adresse" required>
                </div>
                <div class="mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Mot de passe" required>
                </div>
                <button type="submit" class="btn btn-custom w-100">S'inscrire</button>
            </form>
            <div class="text-center mt-3">
                <p class="text-muted">Déjà membre ? <a href="connexion.php" class="text-danger"><u>Connectez-vous</u></a></p>
                <p>Ou continuez avec :</p>
                <div class="social-icons">
                    <a class="btn btn-sm-square bg-primary text-light me-1 rounded-3" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn btn-sm-square bg-primary text-light me-1 rounded-3" href=""><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-sm-square bg-primary text-light me-1 rounded-3" href=""><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn btn-sm-square bg-primary text-light me-0 rounded-3" href=""><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
        
        <!-- Panneau droit -->
        <div class="col-md-6 right-panel">
            <h1>SUPERCAR</h1>
            <p>Vivez l'adrénaline de la vitesse et du luxe comme jamais auparavant.</p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
