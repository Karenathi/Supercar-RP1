<?php
session_start();

if (isset($_GET['i']) && isset($_SESSION['panier_essai'][$_GET['i']])) {
    unset($_SESSION['panier_essai'][$_GET['i']]);
    $_SESSION['panier_essai'] = array_values($_SESSION['panier_essai']); // réindexation propre
}

// 🔥 On revient au panier automatiquement
header("Location: panier.php");
exit();
