<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/client.css">
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <!-- Logo -->
            <a class="navbar-brand" href="#">
                <img src="/client/assets/img/logo1.png" alt="Super Car Logo" class="logo1">
            </a>
            <!-- Navbar Toggle for Mobile -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <!-- Navbar Links -->
            <div class="collapse navbar-collapse justify-content-between" id="navbarNav" >
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="/client/index.php">Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/client/client/voitures.php">Voitures</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/client/client/services.php">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/client/client/login_client.php">Essai Voitures</a>
                    </li>
                    
                </ul>
            </div>

            
           <!-- Contact Button -->
                <a class="btn btn-primary mt-1 ms-auto" href="/client/client/contact.php" role="button">Contactez-nous</a>
        </div>
    </nav>