<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/client/client.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
            display: flex;
            flex-direction: column;
        }

        .main-content {
            flex: 1;
        }

        footer {
            background-color: #b41818;
            color: white;
            padding: 20px 10px;
            text-align: center;
            margin-top: 10rem;
        }

        .legal {
            font-size: 14px;
            margin-top: 10px;
        }

        .contact-info p {
            margin: 5px 0;
        }

        .contact-info a {
            color: white;
            text-decoration: none;
        }

        .contact-info a:hover {
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .footer-content {
                flex-direction: column;
                text-align: center;
            }

            .contact-info {
                margin-top: 10px;
            }
        }
    </style>
</head>


<body>
    
    <footer>
        <div class="container">
            <div class="row footer-content d-flex align-items-center">
                <div class="col-md-6 text-md-start text-center">
                    <img src="/client/assets/img/logofff.png" alt="SuperCar Logo" style="width: 150px; height: auto;">
                </div>
                <div class="col-md-6 text-md-end text-center contact-info">
                    <p><strong>+230 5536-0799</strong></p>
                    <p><a href="contact.php">info@supercar.com</a></p>
                    <p>Rue du Savoir, Ebene, Ile Maurice</p>
                </div>
            </div>
            <p class="legal">&copy; 2025 SuperCar. Tous droits réservés. <u>Mentions légales.</u></p>
        </div>
    </footer>
</body>
</html>
