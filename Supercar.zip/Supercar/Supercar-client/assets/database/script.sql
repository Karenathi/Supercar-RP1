-- Création de la base de données
CREATE DATABASE IF NOT EXISTS ConcessionAuto;
USE ConcessionAuto;

-- Table: client
CREATE TABLE client(
    id_client        INT AUTO_INCREMENT NOT NULL,
    nom_client       VARCHAR(50) NOT NULL,
    prenom_client    VARCHAR(50) NOT NULL,
    email_client     VARCHAR(50) NOT NULL,
    telephone_client VARCHAR(50) NOT NULL,
    adresse_client   VARCHAR(50) NOT NULL,
    password_client  VARCHAR(255) NOT NULL,
    CONSTRAINT client_PK PRIMARY KEY (id_client)
) ENGINE=InnoDB;

-- Table: marque
CREATE TABLE marque(
    id_marque    INT AUTO_INCREMENT NOT NULL,
    nom_marque   VARCHAR(50) NOT NULL,
    pays_origine VARCHAR(50) NOT NULL,
    CONSTRAINT marque_PK PRIMARY KEY (id_marque)
) ENGINE=InnoDB;

-- Table: voiture
CREATE TABLE voiture(
    id_voiture     INT AUTO_INCREMENT NOT NULL,
    modele         VARCHAR(50) NOT NULL,
    prix           FLOAT NOT NULL,
    couleur        VARCHAR(50) NOT NULL,
    kilometrage    FLOAT NOT NULL,
    type_carburant VARCHAR(50) NOT NULL,
    transmission   VARCHAR(50) NOT NULL,
    disponibilite  BOOL NOT NULL,
    id_client      INT NULL,
    id_marque      INT NOT NULL,
    CONSTRAINT voiture_PK PRIMARY KEY (id_voiture),
    CONSTRAINT voiture_client_FK FOREIGN KEY (id_client) REFERENCES client(id_client),
    CONSTRAINT voiture_marque0_FK FOREIGN KEY (id_marque) REFERENCES marque(id_marque)
) ENGINE=InnoDB;

-- Table: essai
CREATE TABLE essai(
    id_essai   INT AUTO_INCREMENT NOT NULL,
    date_essai TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    statut     VARCHAR(50) NOT NULL,
    id_client  INT NOT NULL,
    CONSTRAINT essai_PK PRIMARY KEY (id_essai),
    CONSTRAINT essai_client_FK FOREIGN KEY (id_client) REFERENCES client(id_client)
) ENGINE=InnoDB;

-- Table: admin
CREATE TABLE admin(
    id_admin       INT AUTO_INCREMENT NOT NULL,
    nom_admin      VARCHAR(50) NOT NULL,
    prenom_admin   VARCHAR(50) NOT NULL,
    email_admin    VARCHAR(50) NOT NULL,
    password_admin VARCHAR(255) NOT NULL,
    CONSTRAINT admin_PK PRIMARY KEY (id_admin)
) ENGINE=InnoDB;

-- Table: vendeur
CREATE TABLE vendeur(
    id_vendeur        INT AUTO_INCREMENT NOT NULL,
    nom_vendeur       VARCHAR(50) NOT NULL,
    prenom_vendeur    VARCHAR(50) NOT NULL,
    email_vendeur     VARCHAR(50) NOT NULL,
    telephone_vendeur VARCHAR(50) NOT NULL,
    commission        DECIMAL(10,2) NOT NULL,
    id_admin          INT NOT NULL,
    CONSTRAINT vendeur_PK PRIMARY KEY (id_vendeur),
    CONSTRAINT vendeur_admin_FK FOREIGN KEY (id_admin) REFERENCES admin(id_admin)
) ENGINE=InnoDB;

-- Table: vente
CREATE TABLE vente(
    id_vente   INT AUTO_INCREMENT NOT NULL,
    date_vente TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    prix_final FLOAT NOT NULL,
    id_vendeur INT NOT NULL,
    id_admin   INT NOT NULL,
    CONSTRAINT vente_PK PRIMARY KEY (id_vente),
    CONSTRAINT vente_vendeur_FK FOREIGN KEY (id_vendeur) REFERENCES vendeur(id_vendeur),
    CONSTRAINT vente_admin0_FK FOREIGN KEY (id_admin) REFERENCES admin(id_admin)
) ENGINE=InnoDB;

-- Table: lier
CREATE TABLE lier(
    id_vente   INT NOT NULL,
    id_voiture INT NOT NULL,
    CONSTRAINT lier_PK PRIMARY KEY (id_vente, id_voiture),
    CONSTRAINT lier_vente_FK FOREIGN KEY (id_vente) REFERENCES vente(id_vente),
    CONSTRAINT lier_voiture0_FK FOREIGN KEY (id_voiture) REFERENCES voiture(id_voiture)
) ENGINE=InnoDB;

-- Table: gerer
CREATE TABLE gerer(
    id_admin  INT NOT NULL,
    id_essai  INT NOT NULL,
    CONSTRAINT gerer_PK PRIMARY KEY (id_admin, id_essai),
    CONSTRAINT gerer_admin_FK FOREIGN KEY (id_admin) REFERENCES admin(id_admin),
    CONSTRAINT gerer_essai0_FK FOREIGN KEY (id_essai) REFERENCES essai(id_essai)
) ENGINE=InnoDB;

-- Table: contact
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telephone VARCHAR(20) DEFAULT NULL,
    message TEXT NOT NULL,
    date_envoi TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- Insertion des données de test
INSERT INTO client (nom_client, prenom_client, email_client, telephone_client, adresse_client, password_client)
VALUES ('Dupont', 'Jean', 'jean.dupont@email.com', '0601020304', '12 rue de Paris', 'password123');

INSERT INTO marque (nom_marque, pays_origine)
VALUES ('Toyota', 'Japon'), ('BMW', 'Allemagne'), ('Renault', 'France');

INSERT INTO voiture (modele, prix, couleur, kilometrage, type_carburant, transmission, disponibilite, id_client, id_marque)
VALUES ('Corolla', 20000, 'Rouge', 50000, 'Essence', 'Automatique', TRUE, NULL, 1);

INSERT INTO admin (nom_admin, prenom_admin, email_admin, password_admin)
VALUES ('Admin', 'Principal', 'admin@email.com', 'adminpassword');

INSERT INTO vendeur (nom_vendeur, prenom_vendeur, email_vendeur, telephone_vendeur, commission, id_admin)
VALUES ('Martin', 'Paul', 'paul.martin@email.com', '0605060708', 500.00, 1);

INSERT INTO vente (prix_final, id_vendeur, id_admin)
VALUES (19500, 1, 1);

INSERT INTO lier (id_vente, id_voiture)
VALUES (1, 1);

INSERT INTO essai (statut, id_client)
VALUES ('Validé', 1);

INSERT INTO gerer (id_admin, id_essai)
VALUES (1, 1);
