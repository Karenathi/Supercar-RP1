<?php
session_start();
include('config.php'); 

if (!isset($_GET['i']) || !isset($_SESSION['panier_essai'][$_GET['i']])) {
    echo "<script>alert('Demande invalide.'); window.location.href='panier.php';</script>";
    exit();
}

if (!isset($_SESSION['client_id'])) {
    echo "<script>alert('Vous devez être connecté pour valider une demande.'); window.location.href='connexion.php';</script>";
    exit();
}

$essai = $_SESSION['panier_essai'][$_GET['i']];
$client_id = $_SESSION['client_id'];

try {
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Vérifie valeurs essentielles
    if (empty($essai['carReference'])) throw new Exception("Modèle de voiture vide");
    if (empty($client_id)) throw new Exception("Client non identifié");

    // Conversion date
    $rawDate = str_replace('T', ' ', $essai['testDate']);
    $date = DateTime::createFromFormat('Y-m-d H:i', $rawDate);
    if (!$date) $date = DateTime::createFromFormat('Y-m-d H:i:s', $rawDate);
    if (!$date) throw new Exception("Date invalide pour {$essai['carReference']}: $rawDate");
    $formattedDate = $date->format('Y-m-d H:i:s');

    // Vérifie doublon
    $check = $pdo->prepare("SELECT COUNT(*) FROM essai 
                            WHERE id_client=:id_client 
                            AND car_name=:car_name 
                            AND date_essai=:date_essai");
    $check->execute([
        ':id_client' => $client_id,
        ':car_name' => $essai['carReference'],
        ':date_essai' => $formattedDate
    ]);
    if ($check->fetchColumn() > 0) throw new Exception("Vous avez déjà une demande pour cette voiture à cette date.");

    // Insertion
    $stmt = $pdo->prepare("INSERT INTO essai (date_essai, statut, car_name, id_client)
                           VALUES (:date_essai, 'en_cours', :car_name, :id_client)");
    $stmt->execute([
        ':date_essai' => $formattedDate,
        ':car_name' => $essai['carReference'],
        ':id_client' => $client_id
    ]);

    $insertedId = $pdo->lastInsertId();

    // Supprime du panier
    unset($_SESSION['panier_essai'][$_GET['i']]);
    $_SESSION['panier_essai'] = array_values($_SESSION['panier_essai']);

    echo "<script>alert('✅ Demande validée ! ID: $insertedId'); window.location.href='panier.php';</script>";
    exit();

} catch (Exception $e) {
    echo "<script>alert('❌ Erreur : " . addslashes($e->getMessage()) . "'); window.location.href='panier.php';</script>";
    exit();
}
?>
