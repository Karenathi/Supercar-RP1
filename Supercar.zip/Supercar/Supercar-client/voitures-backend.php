<?php
// Récupération des voitures
$sql = "SELECT * FROM voitures";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$voitures = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
