<!-- Footer Start -->
<div class="container-fluid bg-dark text-light footer pt-3 pb-2 mt-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="row justify-content-center">
        <div class="col-12 col-md-6 text-center">
            <!-- Copyright -->
            <p class="mb-2">&copy; 2025 <a class="border-bottom text-light" href="#">SuperCar</a>. Tous droits réservés.</p>
 
            <!-- Réseaux sociaux -->
            <div class="mb-2">
                <a href="https://www.facebook.com" class="text-light me-3" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-facebook fa-lg"></i>
                </a>
                <a href="https://www.twitter.com" class="text-light me-3" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-twitter fa-lg"></i>
                </a>
                <a href="https://www.instagram.com" class="text-light me-3" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-instagram fa-lg"></i>
                </a>
                <a href="https://www.linkedin.com" class="text-light me-3" target="_blank" rel="noopener noreferrer">
                    <i class="fab fa-linkedin fa-lg"></i>
                </a>
            </div>
 
            <!-- Mentions légales et Politique de confidentialité -->
            <div>
                <a href="#" class="text-light me-3" data-bs-toggle="modal" data-bs-target="#mentionsModal">
                    <u>Mentions légales</u>
                </a>
                <a href="#" class="text-light" data-bs-toggle="modal" data-bs-target="#politiqueModal">
                    <u>Politique de confidentialité</u>
                </a>
            </div>
        </div>
    </div>
 
    <!-- Modal Mentions légales -->
    <div class="modal fade" id="mentionsModal" tabindex="-1" aria-labelledby="mentionsLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content text-dark">
                <div class="modal-header">
                    <h5 class="modal-title" id="mentionsLabel">Mentions légales</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Nom du site :</strong> Supercar</p>
                   
                    <p><strong>Responsables du projet :</strong><br>
                        Karen Andriantasy & Dimitri Meyepa<br>
                        Étudiants en BTS SIO – Réalisation Professionnelle<br>
                        MCCI Business School<br>
                        Rue Savoir, Cybercity, Ebene, Maurice
                    </p>
                   
                    <p><strong>Propriété intellectuelle :</strong><br>
                        L'ensemble du contenu de ce site, incluant textes, images, logos et vidéos, est protégé par le droit d'auteur. Toute reproduction, représentation ou diffusion, totale ou partielle, est interdite sans autorisation préalable des auteurs.
                    </p>
                   
                    <p><strong>Données personnelles :</strong><br>
                        Aucune donnée personnelle n'est collectée, traitée ou conservée sur ce site. Ce site ne contient aucun formulaire de collecte d'informations personnelles.
                    </p>
                   
                    <p><strong>Limitation de responsabilité :</strong><br>
                        Ce site est un prototype académique réalisé dans le cadre d'un projet étudiant. Il n'a pas vocation à représenter une entreprise réelle. Les informations présentées sont fournies à titre indicatif et ne peuvent engager la responsabilité des auteurs.
                    </p>
                   
                    <p><strong>Cookies et traceurs :</strong><br>
                        Ce site n'utilise pas de cookies ni de traceurs pour collecter des données sur les visiteurs.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>
 
    <!-- Modal Politique de confidentialité -->
    <div class="modal fade" id="politiqueModal" tabindex="-1" aria-labelledby="politiqueLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content text-dark">
                <div class="modal-header">
                    <h5 class="modal-title" id="politiqueLabel">Politique de confidentialité</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Introduction</strong><br>
                        Cette politique de confidentialité s'applique au site Supercar. Nous nous engageons à protéger et respecter votre vie privée. Cette politique explique comment nous traitons les informations que vous pourriez nous fournir.
                    </p>
                   
                    <p><strong>Collecte des données</strong><br>
                        Ce site étant un prototype académique, nous ne collectons, ne traitons ni ne stockons aucune donnée personnelle identifiable. Aucun formulaire de collecte d'informations personnelles n'est présent sur ce site.
                    </p>
                   
                    <p><strong>Utilisation des données</strong><br>
                        Étant donné qu'aucune donnée personnelle n'est collectée, nous n'utilisons aucune information personnelle à des fins commerciales, marketing ou autres.
                    </p>
                   
                    <p><strong>Cookies et technologies similaires</strong><br>
                        Ce site n'utilise pas de cookies, balises web ou autres technologies de suivi pour collecter des informations sur les visiteurs.
                    </p>
                   
                    <p><strong>Partage des informations</strong><br>
                        Comme nous ne collectons aucune donnée personnelle, nous ne partageons aucune information avec des tiers.
                    </p>
                   
                    <p><strong>Sécurité</strong><br>
                        Bien que nous ne collections pas de données personnelles, nous mettons en œuvre des mesures de sécurité appropriées pour protéger l'intégrité du site.
                    </p>
                   
                    <p><strong>Vos droits</strong><br>
                        Conformément au RGPD et autres lois sur la protection des données, vous disposez de droits concernant vos données personnelles. Cependant, comme nous ne collectons aucune donnée, ces droits ne s'appliquent pas dans le cadre de ce site.
                    </p>
                   
                    <p><strong>Modifications de cette politique</strong><br>
                        Nous nous réservons le droit de modifier cette politique de confidentialité à tout moment. Toute modification sera publiée sur cette page.
                    </p>
                   
                    <p><strong>Contact</strong><br>
                        Pour toute question relative à cette politique de confidentialité, vous pouvez nous contacter via notre établissement scolaire, MCCI Business School.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Footer End -->