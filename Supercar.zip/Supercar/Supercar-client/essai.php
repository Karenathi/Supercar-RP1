<?php
session_start();
include('config.php');
include('navbar.php');

// Vérifie si on modifie un essai existant
$is_edit = isset($_GET['edit']);
$edit_index = $_GET['edit'] ?? null;

if ($is_edit && isset($_SESSION['panier_essai'][$edit_index])) {
    $essai = $_SESSION['panier_essai'][$edit_index];
    $email = $essai['email'];
    $phone = $essai['phone'];
    $address = $essai['address'];
    $selected_brand = $essai['carBrand'];
    $selected_model = $essai['carReference'];
    $testDate = $essai['testDate'];
} else {
    $testDate = "";
}

// Vérifie si le client est connecté
if (!isset($_SESSION['client_id'])) {
    echo "<script>
        alert('Vous devez être connecté pour faire une demande d\'essai.');
        window.location.href = 'connexion.php';
    </script>";
    exit;
}

// Récupération des infos du client connecté
$client_id = $_SESSION['client_id'];
$clientQuery = "SELECT email_client, telephone_client, adresse_client FROM client WHERE id_client = :id";
$clientStmt = $pdo->prepare($clientQuery);
$clientStmt->bindParam(':id', $client_id);
$clientStmt->execute();
$clientInfo = $clientStmt->fetch(PDO::FETCH_ASSOC);

$email = $clientInfo['email_client'] ?? '';
$phone = $clientInfo['telephone_client'] ?? '';
$address = $clientInfo['adresse_client'] ?? '';

// Récupération des voitures et tri par marque
$voitureQuery = "SELECT car_name FROM voitures";
$voitureStmt = $pdo->query($voitureQuery);
$voitures = $voitureStmt->fetchAll(PDO::FETCH_ASSOC);

$voitureMap = [];

function normalizeBrand($brand)
{
    $brand = strtolower($brand);
    if (strpos($brand, 'mercedes') !== false) return 'Mercedes';
    if (strpos($brand, 'porsche') !== false) return 'Porsche';
    if (strpos($brand, 'audi') !== false) return 'Audi';
    return ucfirst($brand);
}

foreach ($voitures as $v) {
    $fullName = $v['car_name'];
    $firstWord = explode(' ', $fullName)[0];
    $normalizedBrand = normalizeBrand($firstWord);
    $voitureMap[$normalizedBrand][] = $fullName;
}

// Préremplissage marque + modèle depuis URL
$car_name_from_url = $_GET['car_name'] ?? null;
$selected_brand = '';
$selected_model = '';
if ($car_name_from_url) {
    $selected_model = $car_name_from_url;
    $selected_brand = explode(' ', $car_name_from_url)[0];
}

// Gestion POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $carBrand = $_POST['carBrand'];
    $carReference = $_POST['carReference'];
    $testDateRaw = $_POST['testDate'];

    // Conversion de la date au format MySQL
    $dateObj = DateTime::createFromFormat('Y-m-d H:i', $testDateRaw);
    if (!$dateObj) {
        echo "<script>alert('Format de date invalide.'); window.location.href='essai.php';</script>";
        exit();
    }
    $testDateFormatted = $dateObj->format('Y-m-d H:i:s');

    // MODE MODIFICATION
    if (isset($_POST['edit_index'])) {
        $i = $_POST['edit_index'];

        // Vérification doublons date et voiture
        foreach ($_SESSION['panier_essai'] as $key => $item) {
            if ($key != $i && $item['testDate'] == $testDateFormatted) {
                echo "<script>alert('Chaque demande d\'essai doit avoir une date différente.');</script>";
                exit();
            }
            if ($key != $i && $item['carReference'] == $carReference) {
                echo "<script>alert('Vous avez déjà demandé un essai pour cette voiture.');</script>";
                exit();
            }
        }

        $_SESSION['panier_essai'][$i] = [
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
            'carBrand' => $carBrand,
            'carReference' => $carReference,
            'testDate' => $testDateFormatted
        ];

        echo "<script>alert('Modification enregistrée avec succès !'); window.location.href='panier.php';</script>";
        exit;
    }

    // AJOUT NOUVEAU ESSAI
    if (!isset($_SESSION['panier_essai'])) $_SESSION['panier_essai'] = [];

    // Limite 3 essais
    if (count($_SESSION['panier_essai']) >= 3) {
        echo "<script>alert('Vous ne pouvez pas ajouter plus de 3 demandes d\'essai.'); window.location.href='panier.php';</script>";
        exit();
    }

    // Vérification doublons voiture et date
    foreach ($_SESSION['panier_essai'] as $essai) {
        if ($essai['carReference'] == $carReference) {
            echo "<script>alert('Vous avez déjà demandé un essai pour ce modèle.');</script>";
            exit();
        }
        if ($essai['testDate'] == $testDateFormatted) {
            echo "<script>alert('Chaque demande d\'essai doit être à une date différente.');</script>";
            exit();
        }
    }

    $_SESSION['panier_essai'][] = [
        'email' => $email,
        'phone' => $phone,
        'address' => $address,
        'carBrand' => $carBrand,
        'carReference' => $carReference,
        'testDate' => $testDateFormatted
    ];

    echo "<script>alert('Votre demande d\'essai a été ajoutée au panier !'); window.location.href='panier.php';</script>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Essai - Supercar</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <style>
        body {background-image: url('../assets/img/fond-essai.jpg'); background-size: cover; background-position: center; background-attachment: fixed;}
        .container-custom {display: flex; flex-wrap: wrap; justify-content: center; align-items: center; min-height: 100vh; padding: 2rem;}
        .form-container {background-color: rgba(255,255,255,0.9); border-radius: 10px; padding: 40px; width: 100%; max-width: 600px; box-shadow: 0 4px 10px rgba(0,0,0,0.2); margin-top: 6rem;}
        .logo {display: block; margin: 0 auto 1rem; width: 80px;}
        @media (max-width:768px){.form-container{max-width:90%;}}
    </style>
</head>
<body>

<div class="container container-custom">
    <div class="form-container">
        <img src="assets/logo1.png" class="logo" alt="Logo">
        <h2 class="text-center text-danger mb-3">DEMANDE D'ESSAI</h2>

        <form action="" method="post">
            <div class="mb-3">
                <label>Email</label>
                <input type="email" class="form-control" name="email" value="<?= htmlspecialchars($email) ?>" readonly>
            </div>
            <div class="mb-3">
                <label>Téléphone</label>
                <input type="tel" class="form-control" name="phone" value="<?= htmlspecialchars($phone) ?>" required>
            </div>
            <div class="mb-3">
                <label>Adresse</label>
                <input type="text" class="form-control" name="address" value="<?= htmlspecialchars($address) ?>" required>
            </div>
            <div class="mb-3">
                <label>Marque de la voiture</label>
                <select class="form-select" id="carBrand" name="carBrand" required>
                    <option value="">-- Choisissez une marque --</option>
                    <?php foreach (array_keys($voitureMap) as $brand): ?>
                        <option value="<?= htmlspecialchars($brand) ?>" <?= ($selected_brand === $brand ? 'selected' : '') ?>><?= htmlspecialchars($brand) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label>Modèle de la voiture</label>
                <select class="form-select" id="carReference" name="carReference" required>
                    <?php if ($selected_model): ?>
                        <option value="<?= htmlspecialchars($selected_model) ?>" selected><?= htmlspecialchars($selected_model) ?></option>
                    <?php else: ?>
                        <option value="">-- Sélectionnez un modèle --</option>
                    <?php endif; ?>
                </select>
            </div>
            <div class="mb-3">
                <label>Date d’essai</label>
                <input type="text" class="form-control" id="testDate" name="testDate" placeholder="Choisissez une date et une heure" required>
            </div>
            <div class="d-grid">
                <button type="submit" class="btn btn-danger btn-lg">Valider</button>
            </div>
            <?php if ($is_edit): ?>
                <input type="hidden" name="edit_index" value="<?= $edit_index ?>">
            <?php endif; ?>
        </form>
    </div>
</div>

<script>
    const voitureMap = <?= json_encode($voitureMap); ?>;
    document.addEventListener('DOMContentLoaded', function() {
        const brandSelect = document.getElementById('carBrand');
        const modelSelect = document.getElementById('carReference');
        function updateModeles() {
            const selectedBrand = brandSelect.value;
            const modeles = voitureMap[selectedBrand] || [];
            modelSelect.innerHTML = '';
            if (modeles.length === 0) {
                modelSelect.innerHTML = '<option>Aucun modèle disponible</option>';
                return;
            }
            modeles.forEach(modele => {
                const option = document.createElement('option');
                option.value = modele;
                option.textContent = modele;
                modelSelect.appendChild(option);
            });
            const preselectedModel = "<?= isset($selected_model) ? addslashes($selected_model) : '' ?>";
            if (preselectedModel) {
                const match = Array.from(modelSelect.options).find(opt => opt.value === preselectedModel);
                if (match) match.selected = true;
            }
        }
        brandSelect.addEventListener('change', updateModeles);
        updateModeles();
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    flatpickr("#testDate", {
        enableTime: true,
        dateFormat: "Y-m-d H:i",
        minDate: "today",
        minTime: "09:00",
        maxTime: "20:30",
        time_24hr: true
    });
</script>

<?php include('footer.php'); ?>
</body>
</html>
