<?php
session_start();
include('navbar.php');

$panier = $_SESSION['panier_essai'] ?? [];
?>

<div class="container mt-5">
    <h2 class="mb-4">Votre panier d'essais</h2>

    <?php if (empty($panier)): ?>
        <p>Aucune demande d'essai pour le moment.</p>

    <?php else: ?>

        <table class="table table-bordered text-center">
            <thead>
                <tr>
                    <th>Modèle</th>
                    <th>Marque</th>
                    <th>Date</th>
                    <th>Téléphone</th>
                    <th>Adresse</th>
                    <th>Modifier</th>
                    <th>Supprimer</th>
                    <th>Valider</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($panier as $index => $essai): ?>
                    <tr>
                        <td><?= htmlspecialchars($essai['carReference']) ?></td>
                        <td><?= htmlspecialchars($essai['carBrand']) ?></td>
                        <td><?= htmlspecialchars($essai['testDate']) ?></td>
                        <td><?= htmlspecialchars($essai['phone']) ?></td>
                        <td><?= htmlspecialchars($essai['address']) ?></td>

                        <!-- Bouton Modifier -->
                        <td>
                            <a href="essai.php?edit=<?= $index ?>" class="btn btn-sm btn-warning">
                                ✏ Modifier
                            </a>
                        </td>



                        <!-- Bouton supprimer -->
                        <td>
                            <a href="supprimer_essai.php?i=<?= $index ?>"
                                class="btn btn-sm btn-danger"
                                onclick="return confirm('Voulez-vous vraiment supprimer cet essai ?');">
                                X
                            </a>
                        </td>

                        <!-- Bouton valider un -->
                        <td>
                            <a href="valider_essai.php?i=<?= $index ?>"
                                class="btn btn-sm btn-success">✓</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Valider tout -->
        <a href="valider_panier.php" class="btn btn-lg btn-danger mt-3">Valider toutes les demandes</a>

    <?php endif; ?>
</div>

<script>
    function modifierEssai(index, ancienneDate) {
        let nouvelleDate = prompt("Nouvelle date d'essai (AAAA-MM-JJ) :", ancienneDate);

        if (!nouvelleDate) return;

        // Redirection avec la nouvelle date
        window.location.href = "modifier_essai.php?i=" + index + "&date=" + nouvelleDate;
    }
</script>