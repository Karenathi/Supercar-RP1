<?php
session_start();
require('config.php');

if (isset($_SESSION['client_id'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email_client = $_POST['email_client'];
    $password_client = $_POST['password_client'];

    $query = "SELECT * FROM client WHERE email_client = :email_client";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':email_client', $email_client);
    $stmt->execute();

    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($client && password_verify($password_client, $client['password_client'])) {
        $_SESSION['client_id'] = $client['id_client'];
        $_SESSION['client_email'] = $client['email_client'];
        $_SESSION['client_prenom'] = $client['prenom_client'];
        $_SESSION['client_nom'] = $client['nom_client'];

        echo "<script>
               alert('Connexion réussie');
               window.location.href = 'index.php';
         </script>";
        exit;
    } else {
        echo "<script>alert('Email ou mot de passe incorrect.');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Connexion Supercar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        h1 {
            color: white;
        }

        .form-control {
            border-radius: 5px;
            border: white solid 1px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.13);

        }

        body {
            background-color: #f8f9fa;
        }

        .login-container {
            max-width: 900px;
            margin: auto;
            margin-top: 100px;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);

        }

        .left-panel {
            padding: 50px;
        }

        .right-panel {
            background: url('assets/list/right-pannel.png') no-repeat center/cover;
            color: white;
            padding: 50px;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-direction: column;
            position: relative;
        }

        .right-panel::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(183, 28, 28, 0.67);
        }

        .right-panel * {
            position: relative;
            z-index: 1;
        }

        .btn-custom {
            background-color: #d32f2f;
            color: white;
            border: none;
            border-radius: 5px;

        }

        .btn-custom:hover {
            background-color: #b71c1c;
            color: white
        }

        .social-icons a {
            margin: 0 5px;
            color: #d32f2f;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row login-container">
            <!-- Panneau gauche-->
            <div class="col-md-6 left-panel">
                <div class="text-center">
                    <img src="assets/logo1.png" alt="" style="width: 10rem; margin-bottom:2rem;">
                    <p class="text-muted">Connectez-vous d'abord pour accéder à l'univers des supercars de haute performance.</p>
                </div>
                <!-- Form start-->
                <form action="connexion.php" method="POST">

                    <div class="mb-3">
                        <label for="email_client" class="form-label">Email :</label>
                        <input type="email" class="form-control" name="email_client" id="email_client" required placeholder="Saisissez votre email">
                    </div>

                    <div class="mb-3">
                        <label for="password_client" class="form-label">Mot de passe :</label>
                        <input type="password" class="form-control" placeholder=" Saisissez votre mot de passe" name="password_client">
                    </div>

                    <button type="submit" class="btn btn-custom w-100">Se connecter</button>
                </form>
                <div class="text-center mt-3">
                    <p class="text-muted">Pas encore de compte ? <a href="inscription.php" class="text-danger"><u>Inscrivez-vous maintenant</u></a></p>
                    <p>Ou connectez-vous avec :</p>
                    <div class="social-icons">
                        <a class="btn btn-sm-square bg-primary text-light me-1 rounded-3" href=""><i class="fab fa-facebook-f"></i></a>
                        <a class="btn btn-sm-square bg-primary text-light me-1 rounded-3" href=""><i class="fab fa-twitter"></i></a>
                        <a class="btn btn-sm-square bg-primary text-light me-1 rounded-3" href=""><i class="fab fa-linkedin-in"></i></a>
                        <a class="btn btn-sm-square bg-primary text-light me-0 rounded-3" href=""><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
            </div>

            <!-- Panneau droit -->
            <div class="col-md-6 right-panel">
                <h1>SUPERCAR</h1>
                <p>Vivez l'adrénaline de la vitesse et du luxe comme jamais auparavant.</p>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>