<?php
$host = 'localhost';
$port = '3306'; 
$dbname = 'supercar001_db';
$username = 'root';
$password = 'root';

try {
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8",
        $username,
        $password
    );

    // Mode d'erreur : Exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e) {
    die("Erreur : " . $e->getMessage());
}
?>



