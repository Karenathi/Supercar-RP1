<?php
session_start();

$index = $_GET['i'] ?? null;
$nouvelle_date = $_GET['date'] ?? null;

if ($index === null || $nouvelle_date === null) {
    header("Location: panier.php");
    exit;
}

// Vérifier que l'essai existe
if (!isset($_SESSION['panier_essai'][$index])) {
    header("Location: panier.php");
    exit;
}

// Vérifier que la date n'est pas déjà utilisée par un autre essai
foreach ($_SESSION['panier_essai'] as $key => $item) {
    if ($key != $index && $item['testDate'] == $nouvelle_date) {
        echo "<script>alert('❌ Vous avez déjà un essai à cette date. Chaque essai doit être à une date différente.'); window.location='panier.php';</script>";
        exit;
    }
}

// Mise à jour
$_SESSION['panier_essai'][$index]['testDate'] = $nouvelle_date;

echo "<script>alert('✔ Date modifiée avec succès !'); window.location='panier.php';</script>";
exit;
?>
