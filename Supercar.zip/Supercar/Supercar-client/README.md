# Supercar Partie Client



## Technologies utilisées: 
•	PHP
•	MySQL
•	HTML
•	Bootstrap 

# 🎯 Objectif du projet: 

Ce projet a pour objectif de développer un système de gestion de concession automobile permettant la vente et la gestion des véhicules. Il offre aux clients la possibilité de consulter les voitures disponibles, de programmer des essais et d’effectuer des achats en toute simplicité. Les vendeurs peuvent suivre les ventes et percevoir des commissions, tandis que les administrateurs gèrent les véhicules, les utilisateurs et les transactions. Grâce à cette plateforme, l’organisation des ventes est optimisée, garantissant une meilleure gestion des stocks et une expérience utilisateur améliorée. 


# 🚀Instruction d’installation et d’utilisation : 

# Prérequis
Avant de commencer, il faudra installer : 
•	Un serveur local : XAMPP, WAMP ou MAMP 
•	MySQL
•	PHP 7.x ou supérieur 

# Étapes d’installation : 
1.	Cloner le projet : 
git clone https://github.com/Supercar-UI-UX/Client-final.git
cd client 

2.	Configurer la base de données 
a.	Créer la base de données MySQL nommée AutoConcession 
b.	Importez le fichier supercar_db.sql fourni dans database/ dans MySQL 

3.	Vérifiez le fichier config.php dans /config et mettez à jour les informations de connexion à la base de données 

4.	Démarrer le serveur 
a.	Placez le projet dans /www ou /htdocs de votre serveur local 
b.	Lancez Apache et MySQL via votre serveur local 
c.	Accédez à l’application via http://localhost/client



📌**Aperçu du projet**
# Demo : https://github.com/Supercar-UI-UX/Client-final.git

🎉Contributions
**Contributeurs :** 
•	Karen ANDRIANTASY 
•	Dimitri MEYEPA 



# Fonctionnalités 
  **Demande d'essai** 
  Formulaire d'essai envoyé dans la base de données 
  TO DO : connecter à Gmail 

  **Contact**
  Connecté à la base de données et une copie est envoyé par mail  dans 'info.supercar.com@gmail.com'

  **Login**
  TO DO : inclure à la demande d'essai 

  **Voitures**
  TO DO : connecter au backend 

  

  



@Karen Andriantasy 

