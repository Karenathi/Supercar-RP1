
CREATE DATABASE supercar;
USE supercar; 

-- admin 
CREATE TABLE `admin` (
  `id_admin` int NOT NULL,
  `nom_admin` varchar(50) NOT NULL,
  `prenom_admin` varchar(50) NOT NULL,
  `email_admin` varchar(50) NOT NULL,
  `password_admin` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- Table structure for table `client`
CREATE TABLE `client` (
  `id_client` int NOT NULL,
  `nom_client` varchar(50) NOT NULL,
  `prenom_client` varchar(50) NOT NULL,
  `email_client` varchar(50) NOT NULL,
  `telephone_client` varchar(50) NOT NULL,
  `adresse_client` varchar(50) NOT NULL,
  `password_client` varchar(255) NOT NULL
  
  -- Jaelle : jaelle@gmail.com/jesuisjaelle
  -- Karen : karen@gmail.com/jesuiskaren
  -- Dimitri : dimitri@gmail.com/jesuiscon
-- Insert 
INSERT INTO `client` (`nom_client`, `prenom_client`, `email_client`, `telephone_client`, `adresse_client`, `password_client`) VALUES
('Dupont', 'Alice', 'alice.dupont@email.com', '0123456789', '123 Rue des Lilas', 'motdepasse1'),
('Martin', 'Jean', 'jean.martin@email.com', '0987654321', '45 Avenue de la Paix', 'motdepasse2'),
('Bernard', 'Sophie', 'sophie.bernard@email.com', '0678123456', '78 Boulevard Haussmann', 'motdepasse3'),
('Petit', 'Lucas', 'lucas.petit@email.com', '0754321890', '10 Rue Lafayette', 'motdepasse4'),
('Leroy', 'Emma', 'emma.leroy@email.com', '0612345678', '25 Avenue Montaigne', 'motdepasse5'),
('Robert', 'Paul', 'paul.robert@email.com', '0498765432', '99 Rue des Fleurs', 'motdepasse6'),
('Lambert', 'Marie', 'marie.lambert@email.com', '0345678921', '5 Place de la République', 'motdepasse7'),
('Girard', 'Antoine', 'antoine.girard@email.com', '0789456123', '88 Quai de Seine', 'motdepasse8'),
('Moreau', 'Julie', 'julie.moreau@email.com', '0643219876', '11 Rue du Commerce', 'motdepasse9'),
('Durand', 'Thomas', 'thomas.durand@email.com', '0723456789', '17 Avenue des Champs', 'motdepasse10');



-- Table structure for table `contact_messages`
CREATE TABLE `contact_messages` (
  `id` int NOT NULL,
  `nom` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `message` text NOT NULL,
  `date_envoi` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
-- Insert 
INSERT INTO `contact_messages` (`nom`, `email`, `telephone`, `message`) VALUES
('Alice Dupont', 'alice.dupont@email.com', '0123456789', 'Bonjour, j’aimerais en savoir plus sur vos services.'),
('Jean Martin', 'jean.martin@email.com', NULL, 'Je rencontre un problème avec mon compte, pouvez-vous m’aider ?'),
('Sophie Bernard', 'sophie.bernard@email.com', '0987654321', 'J’aimerais prendre rendez-vous avec un conseiller.'),
('Lucas Petit', 'lucas.petit@email.com', '0678123456', 'Votre site web est très intéressant, bravo à l’équipe !'),
('Emma Leroy', 'emma.leroy@email.com', NULL, 'Est-il possible d’avoir une démonstration de votre produit ?'),
('Paul Robert', 'paul.robert@email.com', '0754321890', 'Je voudrais connaître vos tarifs pour un abonnement premium.'),
('Marie Lambert', 'marie.lambert@email.com', NULL, 'J’ai oublié mon mot de passe, comment puis-je le réinitialiser ?'),
('Antoine Girard', 'antoine.girard@email.com', '0612345678', 'Je souhaite postuler à une offre d’emploi chez vous.'),
('Julie Moreau', 'julie.moreau@email.com', '0498765432', 'Pouvez-vous me rappeler demain matin pour discuter d’un partenariat ?'),
('Thomas Durand', 'thomas.durand@email.com', NULL, 'Merci pour votre assistance rapide, service client au top !');



-- Table structure for table `essai`
CREATE TABLE `essai` (
  `id_essai` int NOT NULL AUTO_INCREMENT,
  `date_essai` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `statut` enum('valide', 'en_cours', 'refuse','fini') DEFAULT 'en_cours' NOT NULL,
  `marque` enum('Mercedes', 'Porsche', 'Audi') NOT NULL,
  `id_client` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
--Insert 
INSERT INTO `essai` (`date_essai`, `statut`, `marque`, `id_client`) VALUES
('2025-03-17 10:00:00', 'en_cours', 'Mercedes', 1),
('2025-03-17 11:00:00', 'valide', 'Porsche', 2),
('2025-03-17 12:00:00', 'refuse', 'Audi', 3),
('2025-03-17 13:00:00', 'fini', 'Mercedes', 4),
('2025-03-17 14:00:00', 'en_cours', 'Porsche', 5),
('2025-03-17 15:00:00', 'valide', 'Audi', 6),
('2025-03-17 16:00:00', 'refuse', 'Mercedes', 7),
('2025-03-17 17:00:00', 'fini', 'Porsche', 8),
('2025-03-17 18:00:00', 'en_cours', 'Audi', 9),
('2025-03-17 19:00:00', 'valide', 'Mercedes', 10);


-- Table structure for table `gerer`
CREATE TABLE `gerer` (
  `id_admin` int NOT NULL,
  `id_essai` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Table structure for table `lier`
CREATE TABLE `lier` (
  `id_vente` int NOT NULL,
  `id_voiture` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Table structure for table `vendeur`
CREATE TABLE `vendeur` (
  `id_vendeur` int NOT NULL,
  `nom_vendeur` varchar(50) NOT NULL,
  `prenom_vendeur` varchar(50) NOT NULL,
  `email_vendeur` varchar(50) NOT NULL,
  `telephone_vendeur` varchar(50) NOT NULL,
  `commission` decimal(10,2) NOT NULL,
  `id_admin` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


-- Table structure for table `vente`
CREATE TABLE `vente` (
  `id_vente` int NOT NULL,
  `date_vente` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `prix_final` float NOT NULL,
  `id_vendeur` int NOT NULL,
  `id_admin` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;



-- Table structure for table `voitures`
CREATE TABLE IF NOT EXISTS `voitures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `car_name` varchar(255) NOT NULL,
  `car_ref` varchar(100) NOT NULL,
  `car_image` varchar(255) NOT NULL,
  `car_status` varchar(50) NOT NULL,
  `car_transmission` varchar(50) NOT NULL,
  `fuel_type` varchar(50) NOT NULL,
  `engine_capacity` decimal(5,2) NOT NULL,
  `year` int NOT NULL,
  `car_km` int NOT NULL,
  `car_price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;
-- Insert 
INSERT INTO voitures (id, car_name, car_ref, car_image, car_status, car_transmission, fuel_type, engine_capacity, year, car_km, car_price) 
VALUES 
(NULL, 'Mercedes-Benz C-Class 2018', 'MB-2018-C-Class', 'assets/list/Mercedes-Benz_C-Class_2018.png', 'Available', 'Automatic', 'Gasoline', 2.0, 2018, 25000, 35000.00),
(NULL, 'Mercedes-Benz S63 AMG White', 'MB-S63-AMG', 'assets/list/Mercedes_Benz_S63_AMG_White.png', 'Available', 'Automatic', 'Gasoline', 5.5, 2020, 15000, 120000.00),
(NULL, 'Mercedes Cabriolet', 'MB-Cabriolet', 'assets/list/mercedes_cabriolet.png', 'Sold', 'Automatic', 'Gasoline', 3.0, 2019, 18000, 45000.00),
(NULL, 'Mercedes-Benz GLE 2021', 'MB-GLE-2021', 'assets/list/2021-mercedes-benz-gle-hero.png', 'Available', 'Automatic', 'Diesel', 3.0, 2021, 10000, 70000.00),
(NULL, 'AMG GT63', 'AMG-GT63', 'assets/list/amg-gt63.png', 'Available', 'Automatic', 'Gasoline', 4.0, 2021, 5000, 150000.00),
(NULL, 'Mercedes G-Class', 'MB-G-Class', 'assets/list/g-class.png', 'Available', 'Automatic', 'Gasoline', 4.0, 2022, 8000, 90000.00);


