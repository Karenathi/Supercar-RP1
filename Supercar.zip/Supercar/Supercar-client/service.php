<?php
include('navbar.php');
require_once 'config.php';

// Fetch services from the database
$query = "SELECT * FROM services";
$stmt = $pdo->prepare($query);
$stmt->execute();
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - Supercar</title>
    <script>
        <?php if ($message): ?>
            // Afficher l'alerte avec le message après la soumission
            alert("<?php echo $message; ?>");
        <?php endif; ?>
    </script>
</head>

<body>

    <!-- Page Header Start -->
    <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-bg-2.jpg);">
        <div class="container-fluid page-header-inner py-5">
            <div class="container text-center">
                <h1 class="display-3 text-white mb-3 animated slideInDown">Services</h1>

            </div>
        </div>
    </div>
    <!-- Page Header End -->


    <!-- Service Start -->
    <div class="container-xxl service py-5">
        <div class="container">
            <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                <h1 class="mb-5">Découvrez Nos Services</h1>
            </div>
            <div class="row g-4 wow fadeInUp" data-wow-delay="0.3s">
                <div class="col-lg-4">
                    <div class="nav w-100 nav-pills me-4">
                        <?php foreach ($services as $index => $service): ?>
                            <button class="nav-link w-100 d-flex align-items-center text-start p-4 mb-4 <?= ($index === 0) ? 'active' : '' ?>"
                                data-bs-toggle="pill"
                                data-bs-target="#tab-pane-<?= $service['id'] ?>"
                                type="button">
                                <i class="fa <?= htmlspecialchars($service['icon']) ?> fa-2x me-3"></i>
                                <h4 class="m-0"><?= htmlspecialchars($service['service']) ?></h4>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="tab-content w-100">
                        <?php foreach ($services as $index => $service): ?>
                            <div class="tab-pane fade <?= ($index === 0) ? 'show active' : '' ?>" id="tab-pane-<?= $service['id'] ?>">
                                <div class="row g-4">
                                    <div class="col-md-6" style="min-height: 350px;">
                                        <div class="position-relative h-100">
                                            <img class="position-absolute img-fluid w-100 h-100"
                                                src="<?= htmlspecialchars($service['image']) ?>"
                                                style="object-fit: cover;" alt="">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <h3 class="mb-3">15 Ans D'Expérience dans les Services Automobiles</h3>
                                        <p class="mb-4"><?= htmlspecialchars($service['description']) ?></p>
                                       
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Service End -->

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>

    <?php
    include('footer.php');
    ?>
</body>

</html>