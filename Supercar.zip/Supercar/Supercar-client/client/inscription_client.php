<?php
session_start();
require_once '../config/config.php'; // Inclure la configuration de la base de données

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer les données du formulaire d'inscription
    $nom_client = $_POST['nom_client'];
    $prenom_client = $_POST['prenom_client'];
    $email_client = $_POST['email_client'];
    $password_client = $_POST['password_client'];
    $telephone_client = $_POST['telephone_client'];
    $adresse_client = $_POST['adresse_client'];


    // Hasher le mot de passe avant de le stocker
    $hashed_password = password_hash($password_client, PASSWORD_DEFAULT);

    // Insérer les données dans la base de données
    $query = "INSERT INTO client (nom_client, prenom_client, email_client, telephone_client ,adresse_client,password_client) 
              VALUES (:nom_client, :prenom_client, :email_client, :telephone_client, adresse_client,:password_client)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':nom_client', $nom_client);
    $stmt->bindParam(':prenom_client', $prenom_client);
    $stmt->bindParam(':email_client', $email_client);
    $stmt->bindParam(':telephone_client', $telephone_client);
    $stmt->bindParam(':password_client', $hashed_password);

    if ($stmt->execute()) {
        $_SESSION['client_email'] = $email_client;
        header('Location: essai.php'); // Rediriger après inscription réussie
        exit;
    } else {
        $error_message = "Une erreur est survenue lors de l'inscription. Veuillez réessayer.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription Client</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-center mb-4">Inscription Client</h2>

        <?php if (isset($error_message)) { ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php } ?>

        <form action="inscription_client.php" method="POST">
            <div class="mb-3">
                <label for="nom_client" class="form-label">Nom :</label>
                <input type="text" class="form-control" name="nom_client" required>
            </div>
            <div class="mb-3">
                <label for="prenom_client" class="form-label">Prénom :</label>
                <input type="text" class="form-control" name="prenom_client" required>
            </div>
            <div class="mb-3">
                <label for="email_client" class="form-label">Email :</label>
                <input type="email" class="form-control" name="email_client" required>
            </div>
            <div class="mb-3">
                <label for="password_client" class="form-label">Mot de passe :</label>
                <input type="password" class="form-control" name="password_client" required>
            </div>

            <div class="mb-3">
    <label for="telephone_client" class="form-label">Numéro de téléphone :</label>
    <input type="text" class="form-control" name="telephone_client" required>
</div>

<div class="mb-3">
    <label for="adresse_client" class="form-label">Adresse :</label>
    <input type="text" class="form-control" name="adresse_client" required>
</div>

            <button type="submit" class="btn btn-danger w-100">S'inscrire</button>
        </form>

        <p class="text-center mt-3">Vous avez déjà un compte ? <a href="login_client.php">Se connecter ici</a></p>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
