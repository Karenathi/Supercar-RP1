<?php include('../public/navbar.php'); ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voitures</title>
    
    <style>
        .text {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin-top: 5em;
        }

        .text p {
            width: 50rem;
        }

        .voitures-container {
            margin-top: 5rem;
        }

        .category {
            margin-bottom: 3rem;
        }

        .category-title {
            font-size: 1.8rem;
            font-weight: bold;
            margin-bottom: 1rem;
        }

        .car-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            gap: 20px;
        }

        .card {
            width: 18rem;
            height: 45rem;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card-img-top {
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            background-size: cover;
        }

        .card-body p {
            margin-bottom: 0.5rem;
        }
    </style>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
</head>

<body>
    <br><br><br>

    <div class="text">
        <h1>Liste des voitures</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Laborum optio reprehenderit commodi facere odio omnis.</p>
        <select id="categoryFilter" class="form-select w-auto mt-3">
            <option value="all">Toutes les catégories</option>
            <option value="SUV">SUV</option>
            <option value="Coupé">Coupé</option>
            <option value="Citadine">Citadine</option>
            <option value="Berline">Berline</option>
            <option value="Cabriolet">Cabriolet</option>
        </select>
    </div>

    <div class="container voitures-container">
        <?php 
            $categories = ['SUV', 'Coupé', 'Citadine', 'Berline', 'Cabriolet'];
            foreach ($categories as $category) : 
        ?>
        <div class="category" data-category="<?= $category ?>">
            <h2 class="category-title"> <?= $category ?> </h2>
            <div class="car-row">
                <?php for ($i = 1; $i <= 4; $i++) : ?>
                <div class="card">
                    <img src="https://placehold.co/400" class="card-img-top" alt="<?= $category ?>">
                    <div class="card-body">
                        <p class="text-muted mb-1 text-start">IN-STOCK</p>
                        <h5 class="card-title fw-bold">Modèle <?= $i ?></h5>
                        <ul class="list-unstyled d-flex flex-wrap gap-2">
                            <li class="d-flex align-items-center"><span class="material-symbols-outlined">auto_transmission</span> Automatique</li>
                            <li class="d-flex align-items-center"><span class="material-symbols-outlined">local_gas_station</span> Essence</li>
                            <li class="d-flex align-items-center"><span class="material-symbols-outlined">calendar_month</span> 2022</li>
                            <li class="d-flex align-items-center"><span class="material-symbols-outlined">swap_driving_apps_wheel</span> 10,000 km</li>
                        </ul>
                    </div>
                    <hr class="my-3">
                    <div class="card-body">
                        <p class="fw-bold m-0">Rs. 1,200,000</p>
                    </div>
                </div>
                <?php endfor; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <script>
        document.getElementById("categoryFilter").addEventListener("change", function() {
            let selectedCategory = this.value;
            document.querySelectorAll(".category").forEach(category => {
                if (selectedCategory === "all" || category.getAttribute("data-category") === selectedCategory) {
                    category.style.display = "block";
                } else {
                    category.style.display = "none";
                }
            });
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
