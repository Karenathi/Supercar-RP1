<?php
include('../public/navbar.php'); 
// Inclusion de la connexion à la base de données
include '../config/config.php';

// Inclure PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require '../libs/PHPMailer/src/Exception.php';
require '../libs/PHPMailer/src/PHPMailer.php';
require '../libs/PHPMailer/src/SMTP.php';

$error_message = '';
$success_message = '';

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = $_POST['nom'];
    $email = $_POST['email'];
    $telephone = $_POST['telephone'];
    $message = $_POST['message'];

    // Insérer les données dans la base de données
    $query = "INSERT INTO contact_messages (nom, email, telephone, message) 
              VALUES (:nom, :email, :telephone, :message)";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':nom', $nom);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':telephone', $telephone);
    $stmt->bindParam(':message', $message);

    if ($stmt->execute()) {
        $success_message = "Votre message a été envoyé avec succès !";
        // Préparer l'email avec PHPMailer
        $mail = new PHPMailer(true);
        try {
            // Configuration du serveur SMTP
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';  // Serveur SMTP de Gmail
            $mail->SMTPAuth = true;
            $mail->Username = 'info.supercar.com@gmail.com';  // Ton adresse Gmail
            $mail->Password = 'zwbl epxl rnov zfre';  
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Destinataire
            $mail->setFrom($email, $nom);
            $mail->addAddress('info.supercar.com@gmail.com', 'SuperCar');  // Adresse du destinataire

            // Contenu de l'email
            $mail->isHTML(false);
            $mail->Subject = 'Nouveau message de contact';
            $mail->Body    = "Vous avez reçu un nouveau message de contact :\n\n".
                             "Nom: $nom\n".
                             "Email: $email\n".
                             "Téléphone: $telephone\n\n".
                             "Message:\n$message";

            // Envoyer l'email
            $mail->send();

        } catch (Exception $e) {
            $error_message = "Erreur lors de l'envoi de l'email. Mailer Error: {$mail->ErrorInfo}";
        }

    } else {
        $error_message = "Une erreur s'est produite. Veuillez réessayer.";
    }

}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contactez-Nous</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    
    
    <style>
        html, body {
            margin: 0;
            padding: 0;
        }

        .contact-section {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            padding: 30px 50px;
            margin-top: 160px;
            margin-bottom: 100px;
            margin-left: 100px;
        }

        .btn-submit {
    background-color: red !important;  /* Ajoute !important pour forcer cette couleur */
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px; 
    width: 50%;
    font-size: 1rem;
    cursor: pointer;
}

.btn-submit:hover {
    background-color: darkred !important;  /* Ajoute !important ici aussi */
}


        .contact-info {
            max-width: 40%;
        }

        .contact-header {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .contact-header span {
            color: red;
        }

        .contact-info p {
            font-size: 1rem;
        }

        .contact-info i {
            color: red;
            font-size: 1.2rem;
            margin-right: 10px;
        }

        .contact-form {
            max-width: 55%;
            padding: 20px;
            margin-right: 100px;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            font-size: 1rem;
            margin-bottom: 15px;
        }

        .form-control:focus {
            border: 2px solid black; 
            outline: none; 
            box-shadow: none !important;
        }

        .btn-submit {
            background-color: red !important;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px; 
            width: 50%;
            font-size: 1rem;
            cursor: pointer;
        }

        .btn-submit:hover {
            background-color: darkred;
        }

        /* Responsivité */
        @media (max-width: 1024px) {
            .contact-section {
                flex-direction: column;
                align-items: center;
                padding: 30px;
                margin-left: 0;
            }

            .contact-info, .contact-form {
                max-width: 100%;
                margin-bottom: 30px;
            }

            .contact-header {
                font-size: 2rem;
            }

            .form-control {
                font-size: 0.9rem;
            }

            .btn-submit {
                width: 70%;
            }
        }

        @media (max-width: 768px) {
            .contact-header {
                font-size: 1.8rem;
            }

            .contact-info p {
                font-size: 0.9rem;
            }

            .form-control {
                font-size: 0.85rem;
            }

            .btn-submit {
                width: 80%;
            }
        }

        @media (max-width: 576px) {
            .contact-header {
                font-size: 1.6rem;
            }

            .form-control {
                font-size: 0.8rem;
            }

            .btn-submit {
                width: 90%;
            }
        }
    </style>
</head>
<body>
    <div class="contact-section">
        <div class="contact-info">
            <h1 class="contact-header">Contactez-<span>nous</span></h1> 
            <p>Nous sommes là pour répondre à toutes vos questions concernant nos véhicules, nos services et vos besoins en matière d'automobile. N'hésitez pas à nous contacter !</p> <br>
            <p><i class="bi bi-telephone"></i> +230 5536-0799</p>
            <p><i class="bi bi-envelope"></i>  info@supercar.com</p>
            <p><i class="bi bi-geo-alt"></i>   Rue du Savoir, Ebene, Ile Maurice</p>
        </div>
        <div class="contact-form">
            <form action="" method="post">
                <?php if ($error_message): ?>
                    <div class="alert alert-danger"><?php echo $error_message; ?></div>
                <?php elseif ($success_message): ?>
                    <div class="alert alert-success"><?php echo $success_message; ?></div>
                <?php endif; ?>

                <input type="text" class="form-control" name="nom" placeholder="Nom" required>
                <div style="display: flex; gap: 10px;">
                    <input type="email" class="form-control" name="email" placeholder="Email" required>
                    <input type="text" class="form-control" name="telephone" placeholder="Numéro de téléphone">
                </div>
                <textarea class="form-control" name="message" placeholder="Message" required></textarea>
                <button type="submit" class="btn-submit">Envoyer</button>
            </form>
        </div>
    </div>
    <?php 
include('../public/footer.php'); 
?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


