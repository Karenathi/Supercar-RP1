<?php
session_start();
include('../public/navbar.php');
include('../config/config.php');

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['client_email'])) {
    // Si non, rediriger vers la page de connexion
    header('Location: login_client.php');
    exit;
}

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $carBrand = $_POST['carBrand'];
    $carReference = $_POST['carReference'];
    $testDate = $_POST['testDate'];

    $query = "SELECT id_client FROM client WHERE email_client = :email";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($client) {
        $id_client = $client['id_client'];
        $query = "INSERT INTO essai (date_essai, statut, id_client) VALUES (:date_essai, :statut, :id_client)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':date_essai', $testDate);
        $stmt->bindParam(':statut', $carBrand);
        $stmt->bindParam(':id_client', $id_client);

        if ($stmt->execute()) {
            $success_message = "Demande d'essai enregistrée avec succès !";
        } else {
            $error_message = "Erreur lors de l'enregistrement de la demande d'essai.";
        }
    } else {
        $error_message = "Aucun client trouvé avec cet email.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Demande d'essai</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/client.css">
    <style>
        body {
            background-image: url('../assets/img/fond-essai.jpg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .form-container {
            background-color: rgba(255, 255, 255, 0.9);
            border-radius: 10px;
            padding: 40px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .image-container {
            text-align: center;
            align-items: center;
            margin-top: 8rem;
        }

        .image-container img {
            max-width: 100%;
            height: auto;
            align-items: center;
        }

        .logo {
            display: block;
            margin: 0 auto 1rem;
            width: 80px;
        }

        select option:hover {
            background-color: red !important;
            color: white !important;
        }

        .both-container {
            margin-top: 10rem;
        }
    </style>
</head>

<body>

<div class="container both-container">
    <div class="row justify-content-center">
        <!-- Formulaire à gauche, image à droite en plein écran -->
        <div class="col-12 col-md-6 form-container">
            <img src="../assets/img/logo1.png" class="logo" alt="Logo">
            <h2 class="text-center text-danger mb-3">DEMANDE D'ESSAI</h2>

            <?php if (!empty($error_message)) { ?>
                <div class="alert alert-danger text-center">
                    <?php echo $error_message; ?>
                </div>
            <?php } elseif (!empty($success_message)) { ?>
                <div class="alert alert-success text-center">
                    <?php echo $success_message; ?>
                </div>
            <?php } ?>

            <form action="" method="post">
                <div class="mb-3">
                    <label for="email" class="form-label fw-bold text-dark">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required placeholder="you@gmail.com">
                </div>
                <div class="mb-3">
                    <label for="phone" class="form-label fw-bold text-dark">Téléphone</label>
                    <input type="tel" class="form-control" id="phone" name="phone" required placeholder="+230">
                </div>
                <div class="mb-3">
                    <label for="address" class="form-label fw-bold text-dark">Adresse</label>
                    <input type="text" class="form-control" id="address" name="address" required placeholder="Votre adresse...">
                </div>
                <div class="mb-3">
                    <label for="carBrand" class="form-label fw-bold text-dark">Catégorie de voiture</label>
                    <select class="form-select" id="carBrand" name="carBrand">
                        <option value="cabriolet">Cabriolet</option>
                        <option value="coupe">Coupé</option>
                        <option value="citadine">Citadine</option>
                        <option value="berline">Berline</option>
                        <option value="suv">SUV</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="carReference" class="form-label fw-bold text-dark">Référence de voiture</label>
                    <input type="text" class="form-control" id="carReference" name="carReference" placeholder="A20X">
                </div>
                <div class="mb-3">
                    <label for="testDate" class="form-label fw-bold text-dark">Date d’essai</label>
                    <input type="date" class="form-control" id="testDate" name="testDate">
                </div>

                <div class="d-grid">
                    <button type="submit" class="btn btn-danger btn-lg">Valider</button>
                </div>
            </form>
        </div>

        <!-- Image en mode plein écran (à droite) et en mobile, sous le formulaire -->
        <div class="col-12 col-md-6 image-container">
            <img src="../assets/img/voiture-essai.png" alt="Voiture d'essai">
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php 
include('../public/footer.php'); 
?>
