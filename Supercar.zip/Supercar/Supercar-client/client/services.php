<?php 
include ('../public/navbar.php'); 
?>

<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Services</title>
   <link rel="stylesheet" href="..assets/css/client.css">
    <style>
      .hero-section {
        position: relative;
        background: url("../assets/img/service-fond.jpg") center/cover no-repeat;
        color: white;
        text-align: left;
        padding: 100px 20px;
        margin-bottom: 0;
        height: 30rem;
        padding: -2rem;
      }
      .hero-section::before {
        content: "";
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
      }
      .hero-section h1 {
        font-weight: bold;
        position: relative;
        z-index: 1;
        
      }
      .highlight {
        color: red;
      }
      .feature-container {
        position: relative;
        overflow: hidden;
      }
      .feature-container h2 {
        color: red;
        font-weight: bold;
      }
      .feature-container p {
        color: white;
        font-weight: normal;
      }
      .feature-img {
        display: block;
        width: 100%;
        height: auto;
        margin-bottom: 40px;
        transition: 0.3s ease;
      }
      .feature-container:hover .feature-img {
        filter: brightness(50%);
        cursor: pointer;
        transform: scale(1.1);
      }
      .feature-overlay {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        color: white;
        font-weight: bold;
        text-align: center;
        opacity: 0;
        transition: 0.3s ease;
      }
      .feature-container:hover .feature-overlay {
        opacity: 1;
      }
      .services-title {
        font-size: 2.5rem;
        font-weight: bold;
        color: black;
        text-transform: uppercase;
        letter-spacing: 2px;
        text-align: center;
        margin-top: 50px;
        margin-bottom: 20px;
      }
 
      
    </style>
  </head>
  <body>
   <div class="container-fluid">
      <div class="row hero-section">
        <div class="col-12">
          <h1>
            Entretien automobile de qualité à petit budget <br> 
            <span class="highlight">Maintenance et réparations auto abordables</span>
          </h1>
        </div>
      </div>
 
      <div class="container">
        <h2 class="services-title">Nos Services</h2>
      </div>
 
      <div class="container mt-5">
        <div class="row text-center">
          <div class="col-md-4 feature-container">
            <img
              src="../assets/img/entretien.jpg"
              alt="Entretien et Réparation"
              class="feature-img"
            />
            <div class="feature-overlay">
              <h2>Entretien et Réparation</h2>
              <p>Services d'entretien et de réparation de haute qualité.</p>
            </div>
          </div>
          <div class="col-md-4 feature-container">
            <img
              src="../assets/img/inspection.jpg"
              alt="Contrôle Technique et Inspection"
              class="feature-img"
            />
            <div class="feature-overlay">
              <h2>Contrôle Technique</h2>
              <p>Inspection minutieuse pour assurer votre sécurité.</p>
            </div>
          </div>
          <div class="col-md-4 feature-container">
            <img
              src="../assets/img/personnalisation.jpg"
              alt="Personnalisation et Accessoires"
              class="feature-img"
            />
            <div class="feature-overlay">
              <h2>Personnalisation et Accessoires</h2>
              <p>Ajoutez une touche unique à votre véhicule.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
   
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>
<?php 
include ('../public/footer.php')
?> 