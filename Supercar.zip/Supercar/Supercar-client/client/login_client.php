<?php
session_start();
require_once '../config/config.php'; // Inclure la configuration de la base de données

// Si le client est déjà connecté, le rediriger vers son espace client
if (isset($_SESSION['client_id'])) {
    header('Location: essai.php');
    exit;
}

// Vérifier si le formulaire de connexion a été soumis
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer les données du formulaire
    $email_client = $_POST['email_client'];
    $password_client = $_POST['password_client'];

    // Préparer la requête SQL pour vérifier les informations de connexion
    $query = "SELECT * FROM client WHERE email_client = :email_client";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':email_client', $email_client);
    $stmt->execute();

    // Vérifier si l'utilisateur existe
    $client = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($client && password_verify($password_client, $client['password_client'])) {
        // Si l'utilisateur est trouvé et le mot de passe est correct, on l'authentifie
        $_SESSION['client_id'] = $client['id_client'];
        $_SESSION['client_email'] = $client['email_client'];

        // Rediriger vers l'espace client
        header('Location: ../public/index.html');
        exit;
    } else {
        // Si les informations sont incorrectes
        $error_message = "Email ou mot de passe incorrect.";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion Client</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="container" style="max-width: 400px;">
        <h2 class="text-center mb-4">Connexion Client</h2>

        <?php if (isset($error_message)) { ?>
            <div class="alert alert-danger" role="alert">
                <?php echo $error_message; ?>
            </div>
        <?php } ?>

        <form action="login_client.php" method="POST">
            <div class="mb-3">
                <label for="email_client" class="form-label">Email :</label>
                <input type="email" class="form-control" name="email_client" id="email_client" required>
            </div>
            <div class="mb-3">
                <label for="password_client" class="form-label">Mot de passe :</label>
                <input type="password" class="form-control" name="password_client" id="password_client" required>
            </div>
            <button type="submit" class="btn btn-danger w-100">Se connecter</button>
        </form>

        <p class="text-center mt-3">Pas encore inscrit ? <a href="inscription_client.php">Inscrivez-vous ici</a></p>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
