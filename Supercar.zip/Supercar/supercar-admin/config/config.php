<?php
// Informations de connexion AlwaysData
$host = 'mysql-supercar001.alwaysdata.net'; // hôte AlwaysData
$port = '3306'; // port par défaut
$dbname = 'supercar001_db'; // nom de la base
$username = '435085_supercar'; // utilisateur
$password = 'Motherlode1234!'; // mot de passe


try {
    // Connexion PDO
    $pdo = new PDO(
        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8",
        $username,
        $password
    );

    // Mode d'erreur : Exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Connexion réussie à la base AlwaysData !";

} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>
