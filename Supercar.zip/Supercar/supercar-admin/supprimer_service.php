<?php
require_once 'config/config.php';

if (!isset($_GET['id'])) {
    die("ID du service manquant.");
}

$id = $_GET['id'];

// On récupère d'abord le chemin de l'image pour pouvoir la supprimer
$stmt = $pdo->prepare("SELECT image FROM services WHERE id = :id");
$stmt->execute([':id' => $id]);
$service = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$service) {
    die("Service introuvable.");
}

$imagePath = $service['image'];

// Suppression du service en base
$stmt = $pdo->prepare("DELETE FROM services WHERE id = :id");
$stmt->execute([':id' => $id]);

// Suppression de l'image côté admin
$adminImagePath = __DIR__ . '/' . $imagePath;
if (file_exists($adminImagePath)) {
    unlink($adminImagePath);
}

// Suppression de la copie client si elle existe
$clientImagePath = __DIR__ . '/../supercar/' . $imagePath;
if (file_exists($clientImagePath)) {
    unlink($clientImagePath);
}

header("Location: service.php");
exit();
?>
