<?php
include('config/config.php');
include('includes/navbar.php');
$search = $_GET['search'] ?? '';
 
// Requête SQL
$sql = "SELECT * FROM voitures WHERE car_name LIKE :search OR fuel_type LIKE :search";
$stmt = $pdo->prepare($sql);
$stmt->execute(['search' => '%' . $search . '%']);
$voitures = $stmt->fetchAll();
?>
 
<!doctype html>
<html lang="fr">
 
<head>
    <title>Voitures - Supercar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
    <!-- Google Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />
 
    <!-- Styles communs pour toutes les pages -->
    <link rel="stylesheet" href="css/styles.css">
 
    <!-- Style spécifique à la page -->
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f8f8;
        }
 
        h1.display-5 {
            color: #333;
            text-align: center;
            padding-top: 30px;
            margin-bottom: 30px;
        }
 
        /* Container des voitures */
        .voitures-container .row {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center; /* centre toutes les cartes */
            align-items: stretch;
        }
 
        .col-md-4 {
            flex: 0 0 30%;
            display: flex;
        }
 
        /* Cartes */
        .voitures-container .card {
            margin-bottom: 30px;
            box-shadow: 0 2px 15px rgba(0, 0, 0, 0.1);
            border: none;
            transition: transform 0.2s ease;
            display: flex;
            flex-direction: column;
            width: 100%;
            background-color: #fff;
        }
 
        .voitures-container .card:hover {
            transform: translateY(-5px);
        }
 
        .voitures-container .card img {
            height: 200px;
            object-fit: cover;
            border-top-left-radius: 0.25rem;
            border-top-right-radius: 0.25rem;
        }
 
        .card-body {
            flex-grow: 1;
            padding: 15px;
            display: flex;
            flex-direction: column;
        }
 
        .card-body h5 {
            font-weight: bold;
        }
 
        .card-body ul {
            list-style: none;
            padding: 0;
            margin: 10px 0;
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
        }
 
        .card-body ul li {
            display: flex;
            align-items: center;
            font-size: 0.9rem;
        }
 
        .card-body ul li span {
            margin-right: 5px;
        }
 
        .card-body .btn {
            margin-top: auto;
        }
 
        /* Boutons */
        .btn-primary {
            background-color: #8E1616;
            border-color: #8E1616;
            color: #fff;
        }
 
        .btn-primary:hover {
            background-color: #a01b1b;
            border-color: #a01b1b;
        }
 
        .btn-warning {
            background-color: #8E1616;
            border-color: #8E1616;
            color: #fff;
        }
 
        .btn-warning:hover {
            background-color: #a01b1b;
            border-color: #a01b1b;
        }
 
        .btn-danger {
            background-color: #000;
            border-color: #000;
            color: #fff;
        }
 
        .btn-danger:hover {
            background-color: #333;
            border-color: #333;
        }
 
        /* Recherche */
        .input-group {
            margin: 30px auto;
            max-width: 600px;
            display: flex;
        }
 
        .input-group .form-control,
        .input-group .btn {
            border-radius: 0.25rem;
        }
 
        /* Responsiveness */
        @media screen and (max-width: 992px) {
            .col-md-4 {
                flex: 0 0 45%;
            }
        }
 
        @media screen and (max-width: 768px) {
            .voitures-container .card img {
                height: 180px;
            }
 
            .col-md-4 {
                flex: 0 0 100%;
            }
        }
    </style>
</head>
 
<body>
    <div class="site-section bg-white animated slideInUp">
        <div class="container-fluid">
            <div class="row justify-content-center">
                <div class="col-lg-8 text-center">
                    <h1 class="display-5"><strong>Liste des voitures</strong></h1>
                </div>
            </div>
 
            <!-- Formulaire de recherche -->
            <form class="input-group" method="get" action="voitures.php">
                <input type="text" class="form-control" name="search" placeholder="Rechercher..." value="<?= htmlspecialchars($search) ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">Rechercher</button>
                </div>
            </form>
 
            <!-- Liste de voitures -->
            <div class="container-fluid voitures-container mt-5">
                <div class="add-btn">
                    <a href="ajouter-voiture.php" class="btn btn-primary" title="Ajouter une nouvelle voiture" aria-label="Ajouter">
                        <span class="material-symbols-outlined">add_circle</span>
                    </a>
                </div><br>
 
                <div class="row">
                    <?php if (count($voitures) > 0): ?>
                        <?php foreach ($voitures as $voiture): ?>
                            <div class="col-md-4 col-sm-6 d-flex">
                                <div class="card">
                                    <img src="<?= htmlspecialchars($voiture['car_image']) ?>" alt="<?= htmlspecialchars($voiture['car_name']) ?>">
                                    <div class="card-body d-flex flex-column">
                                        <p class="text-muted mb-1"><?= htmlspecialchars($voiture['car_status']) ?></p>
                                        <h5 class="card-title"><?= htmlspecialchars($voiture['car_name']) ?></h5>
                                        <ul>
                                            <li><span class="material-symbols-outlined">auto_transmission</span><?= htmlspecialchars($voiture['car_transmission']) ?></li>
                                            <li><span class="material-symbols-outlined">local_gas_station</span><?= htmlspecialchars($voiture['fuel_type']) ?></li>
                                            <li><span class="material-symbols-outlined">calendar_month</span><?= htmlspecialchars($voiture['year']) ?></li>
                                            <li><span class="material-symbols-outlined">swap_driving_apps_wheel</span><?= number_format($voiture['car_km'], 0, ',', ' ') ?> km</li>
                                        </ul>
                                        <div class="d-flex justify-content-between mt-auto">
                                            <a href="modifier-voiture.php?action=edit&id=<?= $voiture['id'] ?>" class="btn btn-warning">
                                                <span class="material-symbols-outlined">edit</span>
                                            </a>
                                            <a href="supprimer-voiture.php?action=delete&id=<?= $voiture['id'] ?>" class="btn btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer cette voiture ?')">
                                                <span class="material-symbols-outlined">delete</span>
                                            </a>
                                        </div>
                                    </div>
                                    <hr>
                                    <div class="card-body d-flex justify-content-between align-items-center">
                                        <p class="fw-bold m-0"><?= number_format($voiture['car_price'], 2, ',', ' ') ?> MUR</p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-center">Aucune voiture trouvée.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 
    <!-- JS Scripts -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
</body>
 
</html>