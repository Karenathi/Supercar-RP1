<?php
require 'config/config.php';
include('includes/navbar.php');

// Gestion des mises à jour pour contact_info
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_contact'])) {
        // Mise à jour uniquement de la valeur
        $stmt = $pdo->prepare("UPDATE contact_info SET value = ? WHERE id = ?");
        $stmt->execute([$_POST['contact_value'], $_POST['contact_id']]);
        echo "<script>alert('Information mise à jour avec succès');</script>";
    }

    if (isset($_POST['update_map'])) {
        // Mise à jour du lien de la carte
        $stmt = $pdo->prepare("UPDATE map_config SET iframe_link = ? WHERE id = 1");
        $stmt->execute([$_POST['iframe_link']]);
        echo "<script>alert('Lien de la carte mis à jour avec succès');</script>";
    }
}

// Récupération des informations de contact
$contact_infos = $pdo->query("SELECT * FROM contact_info")->fetchAll();

// Récupération des messages de contact
$contact_messages = $pdo->query("SELECT * FROM contact_messages ORDER BY date_envoi DESC")->fetchAll();

// Récupération du lien iframe de la carte
$map_config = $pdo->query("SELECT * FROM map_config WHERE id = 1")->fetch();
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" />

    <title>Admin - Modifier Informations et Messages</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f2f2f2;
            color: #333;
        }

        .btn-danger {
            background-color: #000;
            border-color: #000;
            color: #fff;
        }
        .btn-warning {
            background-color: #8E1616;
            border-color: #8E1616;
            color: #fff;
        }
        .btn-danger:hover { 
            background-color: #000;
            border-color: #000;
            color: #fff;
        }
        .btn-warning:hover {
            background-color: #8E1616;
            border-color: #8E1616;
            color: #fff;
        }

        h1.display-5 {
          color: #333;
          text-align: center;
          padding-top: 30px;
      
        }
        h2 {
            text-align: center;
            color: #2c3e50;
        }

        .contact-info,
        .contact-messages {
            max-width: 1000px;
            margin: 0 auto;
        }

        .contact-item,
        .message-item {
            background-color: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
        }

        form p {
            margin-bottom: 10px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: 600;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        button {
            background-color: #8E1616;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ccc;

        }

        th {
            background-color: #8E1616;
            color: white;
            padding: 12px;
            text-align: left;

        }

        td {
            padding: 12px;
            text-align: left;
            border-radius: 6px;
        }

        .message-item p {
            margin: 5px 0;
        }

        hr {
            margin-top: 15px;
            border: none;
            border-top: 1px solid #ccc;
        }

        @media (max-width: 600px) {
            body {
                padding: 10px;
            }

            input[type="text"],
            button {
                font-size: 16px;
            }

            h1,
            h2 {
                font-size: 22px;
            }
        }
    </style>
</head>

<body>
    <br>
    <h1 class="Display-5"> <strong> Informations de contact </strong> </h1><br>

    <div class="contact-info">
        <?php foreach ($contact_infos as $contact): ?>
            <div class="contact-item">
                <form method="post">
                    <input type="hidden" name="contact_id" value="<?= $contact['id'] ?>">
                    <p>
                        <label for="contact_value">Information :</label>
                        <input type="text" name="contact_value" value="<?= htmlspecialchars($contact['value']) ?>" required>
                    </p>
                    <p>
                        <button type="submit" name="update_contact">Mettre à jour</button>
                    </p>
                </form>
            </div>
        <?php endforeach; ?>
    </div><br>

    <!-- Section Google Maps -->
    <h2>Localisation</h2>
    <div class="map-container" style="max-width: 60%; margin: 20px auto;">
        <iframe class="position-relative rounded w-100 h-100"
            src="<?= htmlspecialchars($map_config['iframe_link']) ?>"
            frameborder="0" style="min-height: 350px; border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
    </div><br>

    <div class="contact-info">
        <div class="contact-item">
            <h3>Modifier le lien de la carte</h3>
            <form method="post">
                <p>
                    <label for="iframe_link">Lien iframe de Google Maps:</label>
                    <input type="text" name="iframe_link" value="<?= htmlspecialchars($map_config['iframe_link']) ?>" required>
                </p>
                <p>
                    <button type="submit" name="update_map">Mettre à jour la carte</button>
                </p>
            </form>
        </div>
    </div>

    <!-- Section Messages de Contact -->
    <h2>Messages de Contact</h2>
    <div class="contact-messages">
        <table>
            <thead>
                <tr>
                    <th>Nom</th>
                    <th>Email</th>
                    <th>Téléphone</th>
                    <th>Message</th>
                    <th>Date d'envoi</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($contact_messages as $message): ?>
                    <tr>
                        <td><?= htmlspecialchars($message['nom'] ?? '') ?></td>
                        <td><?= htmlspecialchars($message['email'] ?? '') ?></td>
                        <td><?= htmlspecialchars($message['telephone'] ?? '') ?></td>
                        <td><?= nl2br(htmlspecialchars($message['message'] ?? '')) ?></td>
                        <td><?= $message['date_envoi'] ?? '' ?></td>
                       
                        <td>
                           <div class="d-flex gap-2">
                        <a href="modifier_contact.php?id=<?= $message['id'] ?>" class="btn btn-warning" title="Modifier" aria-label="Modifier">
                        <span class="material-symbols-outlined">edit</span>
                        </a>
                        <a href="supprimer_contact.php?id=<?= $message['id'] ?>" class="btn btn-danger" title="Supprimer" aria-label="Supprimer" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce message ?')">
                        <span class="material-symbols-outlined">delete</span>
                        </a>
                        </div>
                        </td>


                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    </div>

   
</body>

</html>