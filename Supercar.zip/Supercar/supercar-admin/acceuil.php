<?php
require 'config/config.php'; 
include('includes/navbar.php');

function synchroniserImage($imagePath)
{
    $filename = basename($imagePath);
    $adminPath = __DIR__ . '/img/' . $filename;
    $clientPath = __DIR__ . '/../supercar/img/' . $filename;

    if (file_exists($adminPath)) {
        if (!copy($adminPath, $clientPath)) {
            echo "Erreur lors de la synchronisation de l'image.";
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_carousel'])) {
        $stmt = $pdo->prepare("SELECT image, background_image FROM carousel WHERE id = ?");
        $stmt->execute([$_POST['carousel_id']]);
        $carousel = $stmt->fetch();

        if ($carousel) {
            $image = $carousel['image'];
            $background_image = $carousel['background_image'];

            if (!empty($_FILES['carousel_image']['name'])) {
                $image = 'img/' . basename($_FILES['carousel_image']['name']);
                move_uploaded_file($_FILES['carousel_image']['tmp_name'], $image);
                synchroniserImage($image);
            }

            if (!empty($_FILES['carousel_background_image']['name'])) {
                $background_image = 'img/' . basename($_FILES['carousel_background_image']['name']);
                move_uploaded_file($_FILES['carousel_background_image']['tmp_name'], $background_image);
                synchroniserImage($background_image);
            }

            $stmt = $pdo->prepare("UPDATE carousel SET title = ?, subtitle = ?, image = ?, background_image = ? WHERE id = ?");
            $stmt->execute([$_POST['carousel_title'], $_POST['carousel_subtitle'], $image, $background_image, $_POST['carousel_id']]);
        }
    } elseif (isset($_POST['delete_carousel'])) {
        $stmt = $pdo->prepare("SELECT image, background_image FROM carousel WHERE id = ?");
        $stmt->execute([$_POST['carousel_id']]);
        $carousel = $stmt->fetch();

        if ($carousel) {
            if (file_exists($carousel['image'])) unlink($carousel['image']);
            if (file_exists($carousel['background_image'])) unlink($carousel['background_image']);

            $stmt = $pdo->prepare("DELETE FROM carousel WHERE id = ?");
            $stmt->execute([$_POST['carousel_id']]);
        }
    } elseif (isset($_POST['add_carousel'])) {
        $image = '';
        $background_image = '';

        if (!empty($_FILES['carousel_image']['name'])) {
            $image = 'img/' . basename($_FILES['carousel_image']['name']);
            move_uploaded_file($_FILES['carousel_image']['tmp_name'], $image);
            synchroniserImage($image);
        }

        if (!empty($_FILES['carousel_background_image']['name'])) {
            $background_image = 'img/' . basename($_FILES['carousel_background_image']['name']);
            move_uploaded_file($_FILES['carousel_background_image']['tmp_name'], $background_image);
            synchroniserImage($background_image);
        }

        $stmt = $pdo->prepare("INSERT INTO carousel (title, subtitle, image, background_image) VALUES (?, ?, ?, ?)");
        $stmt->execute([$_POST['carousel_title'], $_POST['carousel_subtitle'], $image, $background_image]);
    } elseif (isset($_POST['update_about'])) {
        $stmt = $pdo->prepare("SELECT image FROM home_about WHERE id = 1");
        $stmt->execute();
        $about = $stmt->fetch();

        if ($about) {
            $image = $about['image'];
            if (!empty($_FILES['image']['name'])) {
                $image = 'img/' . basename($_FILES['image']['name']);
                move_uploaded_file($_FILES['image']['tmp_name'], $image);
                synchroniserImage($image);
            }

            $stmt = $pdo->prepare("UPDATE home_about SET title = ?, subtitle = ?, description = ?, experience_years = ?, experience_text = ?, image = ? WHERE id = 1");
            $stmt->execute([$_POST['title'], $_POST['subtitle'], $_POST['description'], $_POST['experience_years'], $_POST['experience_text'], $image]);
        }
    } elseif (isset($_POST['update_services'])) {
        foreach ($_POST['service_id'] as $key => $service_id) {
            $stmt = $pdo->prepare("UPDATE home_services SET title = ?, description = ? WHERE id = ?");
            $stmt->execute([$_POST['service_title'][$key], $_POST['service_description'][$key], $service_id]);
        }
    } elseif (isset($_POST['update_stats'])) {
        foreach ($_POST['stat_id'] as $key => $stat_id) {
            $stmt = $pdo->prepare("UPDATE home_stat SET title = ?, value = ? WHERE id = ?");
            $stmt->execute([$_POST['stat_title'][$key], $_POST['stat_value'][$key], $stat_id]);
        }
    }
}

$about = $pdo->query("SELECT * FROM home_about LIMIT 1")->fetch();
$carousels = $pdo->query("SELECT * FROM carousel")->fetchAll();
$services = $pdo->query("SELECT * FROM home_services")->fetchAll();
$stats = $pdo->query("SELECT * FROM home_stat")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Admin - Page d'accueil</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        background-color: #f8f9fa;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }


        h1.display-5 {
        color: #333;
        text-align: center;
        padding-top: 30px;
        margin-bottom: 30px;
      
        }

    h2 {
        color: #8E1616;
        margin-bottom: 20px;
        font-weight: 600;
        border-bottom: 2px solid #8E1616;
        padding-bottom: 10px;
    }

    .btn-custom {
        background-color: #8E1616;
        color: white;
        border: none;
        padding: 10px 20px;
        transition: background-color 0.3s ease;
        font-weight: 500;
        border-radius: 5px;
    }

    .btn-custom:hover {
        background-color: #8E1616;
        color: white;
    }

    .form-control,
    textarea {
        margin-bottom: 20px;
        border-radius: 6px;
        border: 1px solid #dee2e6;
        padding: 10px 12px;
        font-size: 15px;
        box-shadow: none;
        transition: border-color 0.3s ease;
    }

    .form-control:focus,
    textarea:focus {
        border-color: #8E1616;
        outline: none;
    }

    .form-group {
        background-color: #ffffff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        margin-bottom: 30px;
    }

    .carousel-image,
    .background-image {
        width: 100%;
        max-width: 150px;
        height: 100px;
        object-fit: cover;
        border-radius: 5px;
        border: 1px solid #dee2e6;
    }

    .image-upload-container {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
        margin-bottom: 20px;
    }

    .carousel-item-form {
        background-color: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        padding: 25px;
        margin-bottom: 25px;
    }

    .carousel-item-form .btn {
        margin-right: 10px;
    }

    input[type="file"] {
        padding: 5px;
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        border-radius: 6px;
    }

    .card {
        margin-bottom: 30px;
        border-radius: 10px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        transition: transform 0.3s ease;
    }

    .card:hover {
        transform: translateY(-5px);
    }

    .card-header {
        background-color: #8E1616;
        color: white;
        font-weight: 600;
        font-size: 20px;
        padding: 15px;
    }

    .card-body {
        background-color: #ffffff;
        padding: 25px;
    }

    .image-upload-container img {
        max-width: 120px;
        max-height: 120px;
        object-fit: cover;
        border-radius: 5px;
    }

    @media (max-width: 768px) {
        .image-upload-container {
            align-items: center;
        }

        .carousel-item-form {
            padding: 20px;
        }
    }
</style>

<script>
    function confirmDelete() {
        return confirm("Êtes-vous certain de supprimer ?");
    }
</script>
</head>
<body>
<div class="container mt-5">
<h1 class="Display-5"><strong>Page d'acceuil</strong> </h1>

    <!-- Carousel Section -->
    <div class="card">
        <div class="card-header">Carousel</div>
        <div class="card-body">
            <ul class="list-group">
                <?php foreach ($carousels as $carousel): ?>
                    <li class="list-group-item carousel-item-form">
                        <form method="post" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-3 col-sm-6">
                                    <div class="image-upload-container">
                                        <img src="<?= $carousel['image'] ?>" class="carousel-image">
                                        <input type="file" name="carousel_image" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6">
                                    <div class="image-upload-container">
                                        <img src="<?= $carousel['background_image'] ?>" class="background-image">
                                        <input type="file" name="carousel_background_image" class="form-control">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <input type="hidden" name="carousel_id" value="<?= $carousel['id'] ?>">
                                    <input type="text" name="carousel_title" value="<?= $carousel['title'] ?>" class="form-control" required>
                                    <input type="text" name="carousel_subtitle" value="<?= $carousel['subtitle'] ?>" class="form-control" required>
                                    <div class="d-flex mt-2">
                                        <button type="submit" name="update_carousel" class="btn btn-custom">Enregistrer</button>
                                        <button type="submit" name="delete_carousel" onclick="return confirmDelete();" class="btn btn-custom ml-2">Supprimer</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <!-- Add Carousel -->
    <div class="card">
        <div class="card-header">Ajouter un nouvel élément au Carousel</div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <input type="text" name="carousel_title" placeholder="Titre" required class="form-control">
                <input type="text" name="carousel_subtitle" placeholder="Sous-titre" required class="form-control">
                <input type="file" name="carousel_image" required class="form-control">
                <input type="file" name="carousel_background_image" required class="form-control">
                <button type="submit" name="add_carousel" class="btn btn-custom mt-3">Ajouter</button>
            </form>
        </div>
    </div>

    <!-- Services Section -->
    <div class="card">
        <div class="card-header">Services</div>
        <div class="card-body">
            <form method="post">
                <?php foreach ($services as $service): ?>
                    <div class="form-group">
                        <input type="hidden" name="service_id[]" value="<?= $service['id'] ?>">
                        <input type="text" name="service_title[]" value="<?= $service['title'] ?>" required class="form-control">
                        <textarea name="service_description[]" class="form-control"><?= $service['description'] ?></textarea>
                    </div>
                <?php endforeach; ?>
                <button type="submit" name="update_services" class="btn btn-custom">Mettre à jour les services</button>
            </form>
        </div>
    </div>

    <!-- About Section -->
    <div class="card">
        <div class="card-header">À propos</div>
        <div class="card-body">
            <form method="post" enctype="multipart/form-data">
                <input type="text" name="title" value="<?= $about['title'] ?>" required class="form-control">
                <input type="text" name="subtitle" value="<?= $about['subtitle'] ?>" required class="form-control">
                <textarea name="description" class="form-control"><?= $about['description'] ?></textarea>
                <input type="text" name="experience_years" value="<?= $about['experience_years'] ?>" class="form-control">
                <textarea name="experience_text" class="form-control"><?= $about['experience_text'] ?></textarea>
                <div class="image-upload-container mt-2">
                    <img src="<?= $about['image'] ?>" class="carousel-image">
                    <input type="file" name="image" class="form-control">
                </div>
                <button type="submit" name="update_about" class="btn btn-custom mt-3">Mettre à jour À propos</button>
            </form>
        </div>
    </div>

    <!-- Stats Section -->
    <div class="card">
        <div class="card-header">Statistiques</div>
        <div class="card-body">
            <form method="post">
                <?php foreach ($stats as $stat): ?>
                    <div class="form-group">
                        <input type="hidden" name="stat_id[]" value="<?= $stat['id'] ?>">
                        <input type="text" name="stat_title[]" value="<?= $stat['title'] ?>" required class="form-control">
                        <input type="text" name="stat_value[]" value="<?= $stat['value'] ?>" required class="form-control">
                    </div>
                <?php endforeach; ?>
                <button type="submit" name="update_stats" class="btn btn-custom">Mettre à jour les statistiques</button>
            </form>
        </div>
    </div>

</div>
</body>
</html>
