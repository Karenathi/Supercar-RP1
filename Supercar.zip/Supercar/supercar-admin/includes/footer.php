<!-- Footer Start -->
<div class="container-fluid text-dark footer pt-1 pb-1 mt-5 wow fadeIn bg" data-wow-delay="0.1s">
    <div class="container">
        <!-- Texte centré -->
        <div class="row">
            <div class="col-12 text-center mb-4">
                <p>&copy; 2025 <a class="border-bottom text-dark" href="#">SuperCar</a>. Tous droits réservés.</p>
            </div>
        </div>
        <!-- Icônes des réseaux sociaux -->
        <div class="row justify-content-center">
            <div class="col-auto">
                <a href="https://www.facebook.com" class="text-dark me-3" target="_blank" rel="noopener noreferrer"><i class="fab fa-facebook fa-2x"></i></a>
                <a href="https://www.twitter.com" class="text-dark me-3" target="_blank" rel="noopener noreferrer"><i class="fab fa-twitter fa-2x"></i></a>
                <a href="https://www.instagram.com" class="text-dark me-3" target="_blank" rel="noopener noreferrer"><i class="fab fa-instagram fa-2x"></i></a>
                <a href="https://www.linkedin.com" class="text-dark me-3" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin fa-2x"></i></a>
            </div>
        </div>
    </div>
</div>

<style>
    .bg{
        background-color: gainsboro;
        border: gainsboro solid 1px;
    }
</style>
<!-- Footer End -->
