<?php
include('includes/header.php');
include('includes/navbar.php');
require_once 'config/config.php';

$query = "SELECT * FROM services";
$stmt = $pdo->prepare($query);
$stmt->execute();
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestion des Services</title>
  <link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f7fc;
    }

    h1.display-5 {
      color: #333;
      text-align: center;
      padding-top: 30px;
      
    }

    

    .btn-primary,
    .btn-danger {
      background-color: #8E1616;
      border-color: #8E1616;
      color: #fff;
      font-weight: 600;
      transition: all 0.3s ease;
    }

    .btn-primary:hover,
    .btn-danger:hover {
      background-color: #701111;
      border-color: #701111;
    }

    

    .table thead th {
      background-color: #fff;
      color: #8E1616;
      border-bottom: none;
      font-weight: 600;
      font-size: 15px;
    }

    .table td,
    .table th {
      vertical-align: middle;
      text-align: center;
      
    }

    .table td {
      background: #fff;
      box-shadow: 0px 2px 8px rgba(0, 0, 0, 0.05);
      border: none;
    }

    .table img {
      max-width: 80px;
      height: auto;
      border-radius: 5px;
    }

    .material-symbols-outlined {
      vertical-align: middle;
      font-size: 20px;
    }

    .btn-sm {
      padding: 5px 10px;
      font-size: 14px;
      margin: 2px;
    }

    @media (max-width: 768px) {
      .table thead {
        display: none;
      }

      .table,
      .table tbody,
      .table tr,
      .table td {
        display: block;
        width: 100%;
      }

      .table tr {
        margin-bottom: 15px;
        border-bottom: 1px solid #ccc;
      }

      .table td {
        text-align: left;
        padding-left: 50%;
        position: relative;
      }

      .table td::before {
        content: attr(data-label);
        position: absolute;
        left: 10px;
        width: 45%;
        padding-right: 10px;
        font-weight: bold;
        color: #333;
      }
    }
  </style>
</head>

<body>

  <div class="container">
    <h1 class="display-5"><strong>Gestion des Services</strong></h1>
    <div class="d-flex justify-content-end mb-4">
      <a href="ajouter_service.php" class="btn btn-primary" title="Ajouter un service">
        <span class="material-symbols-outlined">add_circle</span>
      </a>
    </div>

    <div class="table-responsive">
      <table class="table">
        <thead>
          <tr>
            <th>Image</th>
            <th>Service</th>
            <th>Titre</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($services as $service): ?>
            <tr>
              <td data-label="Image">
                <img src="<?= htmlspecialchars($service['image']) ?>" alt="image service" class="img-fluid img-thumbnail">
              </td>
              <td data-label="Service"><?= htmlspecialchars($service['service']) ?></td>
              <td data-label="Titre"><?= htmlspecialchars($service['title']) ?></td>
              <td data-label="Description"><?= htmlspecialchars($service['description']) ?></td>
              <td data-label="Actions">
                <a href="modifier_service.php?id=<?= $service['id'] ?>" class="btn btn-primary btn-sm" title="Modifier">
                  <span class="material-symbols-outlined">edit</span>
                </a>
                <a href="supprimer_service.php?id=<?= $service['id'] ?>" class="btn btn-danger btn-sm" title="Supprimer" onclick="return confirm('Voulez-vous vraiment supprimer ce service ?');">
                  <span class="material-symbols-outlined">delete</span>
                </a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
