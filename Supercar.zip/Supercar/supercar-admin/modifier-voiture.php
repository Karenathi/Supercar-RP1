<?php 
include('config/config.php');  // Connexion à la base de données
include('includes/navbar.php');

// Vérifier si l'ID de la voiture est passé en paramètre dans l'URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Récupérer les données de la voiture à modifier
    $sql = "SELECT * FROM voitures WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['id' => $id]);
    $voiture = $stmt->fetch();

    // Vérifier si la voiture existe
    if (!$voiture) {
        die("Voiture non trouvée !");
    }
}

// Traitement du formulaire de modification
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupérer les données du formulaire
    $car_name = $_POST['car_name'];
    $fuel_type = $_POST['fuel_type'];
    $year = $_POST['year'];
    $car_transmission = $_POST['car_transmission'];
    $car_km = $_POST['car_km'];
    $car_price = $_POST['car_price'];
    $car_status = $_POST['car_status'];

    // Initialiser l'image actuelle
    $car_image = $voiture['car_image'];

    // Vérifier si une nouvelle image a été téléchargée
    if (!empty($_FILES['car_image']['name'])) {
        // Nouveau nom pour l'image
        $car_image_name = basename($_FILES['car_image']['name']);
        $car_image_path = 'assets/list/' . $car_image_name;

        // Vérifier si le fichier est une image valide
        $image_file_type = strtolower(pathinfo($car_image_path, PATHINFO_EXTENSION));
        $valid_image_types = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($image_file_type, $valid_image_types)) {
            // Déplacer l'image téléchargée dans le dossier 'assets/list'
            if (move_uploaded_file($_FILES['car_image']['tmp_name'], $car_image_path)) {
                // Synchroniser l'image dans le répertoire Client
                synchroniserImage($car_image_name);
            } else {
                die("Erreur lors de l'upload de l'image.");
            }
        } else {
            die("Le fichier téléchargé n'est pas une image valide.");
        }

        // Mettre à jour l'image dans la base de données
        $car_image = $car_image_path;
    }

    // Mettre à jour les informations de la voiture dans la base de données
    $update_sql = "UPDATE voitures SET car_name = :car_name, fuel_type = :fuel_type, year = :year, car_transmission = :car_transmission, car_km = :car_km, car_price = :car_price, car_status = :car_status, car_image = :car_image WHERE id = :id";
    $update_stmt = $pdo->prepare($update_sql);
    $update_stmt->execute([
        'car_name' => $car_name,
        'fuel_type' => $fuel_type,
        'year' => $year,
        'car_transmission' => $car_transmission,
        'car_km' => $car_km,
        'car_price' => $car_price,
        'car_status' => $car_status,
        'car_image' => $car_image,
        'id' => $id
    ]);

    // Rediriger vers la page liste des voitures après modification
    header('Location: voitures.php');
    exit;
}

// Fonction de synchronisation
function synchroniserImage($imageName) {
    $adminDir = __DIR__ . '/assets/list/'; 
    $clientDir = __DIR__ . '/../supercar/assets/list/'; 

    // Vérifier si l'image existe dans le répertoire Admin
    if (file_exists($adminDir . $imageName)) {
        // Copier l'image dans le répertoire Client
        if (!copy($adminDir . $imageName, $clientDir . $imageName)) {
            echo "Erreur lors de la copie de l'image vers le dossier client.";
        }
    } else {
        echo "Image non trouvée dans le dossier Admin.";
    }
}
?>

<!doctype html>
<html lang="fr">
<head>
    <title>Modifier Voiture - Supercar</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            border: 2px solid #8e1616; /* Cadre rouge */
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Légère ombre */
        }
        .form-control {
            border-radius: 0;
        }
        .btn-primary {
            background-color: #8e1616;
            border: none;
        }
        .btn-secondary {
            background-color: #f8f9fa;
            border: none;
            color: #8e1616;
        }
        .navbar {
            margin-bottom: 30px;
        }
        h2 {
            color: #8e1616;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2 class="text-center mb-4">Modifier la voiture</h2>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="car_name">Nom de la voiture</label>
                <input type="text" class="form-control" id="car_name" name="car_name" value="<?= htmlspecialchars($voiture['car_name']) ?>" required>
            </div>
            <div class="form-group">
            <label for="fuel_type">Type de carburant</label>
            <select class="form-control" id="fuel_type" name="fuel_type" required>
                <option value="Essence" <?= $voiture['fuel_type'] == 'essence' ? 'selected' : '' ?>>Essence</option>
                <option value="Diesel" <?= $voiture['fuel_type'] == 'diesel' ? 'selected' : '' ?>>Diesel</option>
                <option value="Électrique" <?= $voiture['fuel_type'] == 'electrique' ? 'selected' : '' ?>>Électrique</option>
                <option value="Hybride" <?= $voiture['fuel_type'] == 'hybride' ? 'selected' : '' ?>>Hybride</option>
            </select>
            </div>
            <div class="form-group">
                <label for="year">Année</label>
                <input type="number" class="form-control" id="year" name="year" value="<?= htmlspecialchars($voiture['year']) ?>" required>
            </div>
            <div class="form-group">
            <label for="car_transmission">Transmission</label>
            <select class="form-control" id="car_transmission" name="car_transmission" required>
                <option value="Automatique" <?= $voiture['car_transmission'] == 'automatique' ? 'selected' : '' ?>>Automatique</option>
                <option value="Manuelle" <?= $voiture['car_transmission'] == 'manuelle' ? 'selected' : '' ?>>Manuelle</option>
            </select>
            </div>
            <div class="form-group">
                <label for="car_km">Kilométrage</label>
                <input type="number" class="form-control" id="car_km" name="car_km" value="<?= htmlspecialchars($voiture['car_km']) ?>" required>
            </div>
            <div class="form-group">
                <label for="car_price">Prix</label>
                <input type="number" class="form-control" id="car_price" name="car_price" value="<?= htmlspecialchars($voiture['car_price']) ?>" required>
            </div>
            <div class="form-group">
            <label for="car_status">Statut</label>
            <select class="form-control" id="car_status" name="car_status" required>
            <option value="Disponible" <?= $voiture['car_status'] == 'disponible' ? 'selected' : '' ?>>Disponible</option>
            <option value="Vendu" <?= $voiture['car_status'] == 'vendu' ? 'selected' : '' ?>>Vendu</option>
            </select>
            </div>
            <div class="form-group">
                <label for="car_image">Image de la voiture</label>
                <input type="file" class="form-control" id="car_image" name="car_image" accept="image/*">
            </div>

            <!-- Affichage de l'image actuelle -->
            <div class="form-group">
                <label>Image actuelle:</label>
                <br>
                <img src="<?= $voiture['car_image'] ?>" alt="Image de la voiture" style="width: 200px; height: auto;">
            </div>

            <button type="submit" class="btn btn-primary">Mettre à jour</button>
            <a href="voitures.php" class="btn btn-secondary">Retour à la liste</a>
        </form>
    </div>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>
