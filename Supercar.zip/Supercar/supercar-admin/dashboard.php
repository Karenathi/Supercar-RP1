<?php
include 'config/config.php';
include 'includes/navbar.php';

// Comptages
$sql = "SELECT
            (SELECT COUNT(*) FROM contact_messages) AS total_contacts,
            (SELECT COUNT(*) FROM essai) AS total_essais";
$result = $pdo->query($sql);
$row = $result->fetch(PDO::FETCH_ASSOC);
$totalContacts = $row["total_contacts"] ?? 0;
$totalEssais = $row["total_essais"] ?? 0;

$sqlClients = "SELECT COUNT(*) AS total_clients FROM client";
$resultClients = $pdo->query($sqlClients);
$rowClients = $resultClients->fetch(PDO::FETCH_ASSOC);
$totalClients = $rowClients['total_clients'] ?? 0;

$sqlCars = "SELECT
                SUM(CASE WHEN car_status = 'disponible' THEN 1 ELSE 0 END) AS available_cars,
                SUM(CASE WHEN car_status = 'vendu' THEN 1 ELSE 0 END) AS sold_cars
            FROM voitures";
$resultCars = $pdo->query($sqlCars);
$rowCars = $resultCars->fetch(PDO::FETCH_ASSOC);
$availableCars = $rowCars['available_cars'] ?? 0;
$soldCars = $rowCars['sold_cars'] ?? 0;

$sqlClientsData = "SELECT id_client, nom_client, prenom_client, email_client, telephone_client, adresse_client FROM client";
$resultClientsData = $pdo->query($sqlClientsData);
$clients = $resultClientsData->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Admin</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
        background: linear-gradient(135deg, #f4f7fb, #e9eff5);
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        color: #333;
    }

    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
    }

    .row.text-center {
        justify-content: center;
    }

    .card {
        border-radius: 12px;
        border: none;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .card:hover {
        transform: translateY(-10px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
    }

    .stat-card {
        background-color: #ffffff;
        color: #333;
        padding: 30px;
    }

    .card h3 {
        color: #555;
        font-weight: 600;
        font-size: 24px;
    }

    .fs-2 {
        font-size: 3rem;
        font-weight: 700;
        color: #d9534f;
    }

    .chart-card {
        background: #ffffff;
        padding: 30px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
        border-radius: 0;
    }

    h2 {
        font-size: 2rem;
        font-weight: 700;
        color: #555;
    }

    .table thead {
        background: #343a40;
        color: white;
    }

    .table th {
        background: #dc3545;
        color: white;
    }

    .table tbody tr:nth-child(even) {
        background: #f9f9f9;
    }

    .table tbody tr:hover {
        background: #f1f1f1;
        cursor: pointer;
    }

   
    .clients a {
        display: inline-block;
        font-weight: 600;
        font-size: 18px;
        color: #ffffff !important;
        background-color: #8E1616;
        padding: 12px 25px;
        text-decoration: none;
        border-radius: 30px;
        text-align: center;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        transition: background-color 0.3s ease, transform 0.3s ease;
    }

    .clients a:hover {
        background-color: #8E1616;
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
    }

    .clients a:focus {
        outline: none;
    }

    .clients a:active {
        transform: translateY(1px);
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
    }

    @media (max-width: 768px) {
        .card {
            margin-bottom: 20px;
        }

        .row.mt-4 .col-md-6 {
            margin-bottom: 20px;
        }

        .table thead {
            display: none;
        }

        .table,
        .table tbody,
        .table tr,
        .table td {
            display: block;
            width: 100%;
        }

        .table tr {
            margin-bottom: 1.5rem;
            border-bottom: 2px solid #dee2e6;
            padding-bottom: 1rem;
            background: #fff;
        }

        .table td {
            text-align: left;
            padding: 0.75rem;
            font-size: 15px;
            position: relative;
        }

        .table td::before {
            content: attr(data-label);
            font-weight: bold;
            color: #495057;
            display: block;
            margin-bottom: 5px;
        }

        .clients a {
            color: #343a40;
        }
    }
</style>


</head>

<body>
  <div class="container mt-5">
    <div class="row text-center">
      <div class="col-md-6">
        <div class="card stat-card p-4 shadow-sm">
          <h3>Demandes d'Essai</h3>
          <div class="fs-2 fw-bold" id="totalEssais"><?= $totalEssais; ?></div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card stat-card p-4 shadow-sm">
          <h3>Messages de Contact</h3>
          <div class="fs-2 fw-bold" id="totalContacts"><?= $totalContacts; ?></div>
        </div>
      </div>
    </div>



    <div class="row mt-4">
      <div class="col-md-6">
        <div class="card chart-card p-4">
          <canvas id="usersChart"></canvas>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card chart-card p-4">
          <canvas id="carsChart"></canvas>
        </div>
      </div>
    </div>
  </div>



  <script>
  document.addEventListener("DOMContentLoaded", function() {
    const totalClients = <?= json_encode($totalClients); ?>;
    const ctxUsers = document.getElementById('usersChart').getContext('2d');
    new Chart(ctxUsers, {
      type: 'bar',
      data: {
        labels: ['Total Utilisateurs'],
        datasets: [{
          label: 'Nombre d\'utilisateurs inscrits',
          data: [totalClients],
          backgroundColor: '#FF4545',
          borderColor: '#FF4545',
          borderWidth: 1,
          borderRadius: 4,
          barThickness: 50,
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                if (Number.isInteger(value)) {
                  return value;
                }
              },
              stepSize: 1
            }
          }
        }
      }
    });

    const availableCars = <?= json_encode($availableCars); ?>;
    const soldCars = <?= json_encode($soldCars); ?>;
    const ctxCars = document.getElementById('carsChart').getContext('2d');
    new Chart(ctxCars, {
      type: 'bar',
      data: {
        labels: ['Voitures'],
        datasets: [{
          label: 'Voitures Disponibles',
          data: [availableCars],
          backgroundColor: '#B82132',
          borderColor: '#B82132',
          borderWidth: 1,
          borderRadius: 4,
          barThickness: 50,
        }, {
          label: 'Voitures Vendues',
          data: [soldCars],
          backgroundColor: '#F6D6D6',
          borderColor: '#F6D6D6',
          borderWidth: 1,
          borderRadius: 4,
          barThickness: 50,
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                if (Number.isInteger(value)) {
                  return value;
                }
              },
              stepSize: 1
            }
          }
        }
      }
    });
  });
</script>


  
<div class="container mt-3 clients">
      <a href="clients.php" class="text-dark">Liste des clients</a>
    </div>


  

</html>