<?php
require_once 'config/config.php';
include('includes/navbar.php');

if (!isset($_GET['id'])) {
  die("ID du service manquant.");
}

$id = $_GET['id'];
$query = "SELECT * FROM services WHERE id = :id";
$stmt = $pdo->prepare($query);
$stmt->execute([':id' => $id]);
$service = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$service) {
  die("Service introuvable.");
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $service_name = $_POST['service'];
  $title = $_POST['title'];
  $description = $_POST['description'];

  if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = 'img/';
    $imageName = time() . '_' . basename($_FILES['image']['name']);
    $imagePath = $uploadDir . $imageName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
      synchroniserImage($imagePath);
    } else {
      echo "Erreur lors du téléchargement de l'image.";
      $imagePath = $service['image']; // fallback
    }
  } else {
    $imagePath = $service['image'];
  }

  $update = "UPDATE services SET service = :service, title = :title, description = :description, image = :image WHERE id = :id";
  $stmt = $pdo->prepare($update);
  $stmt->execute([
    ':service' => $service_name,
    ':title' => $title,
    ':description' => $description,
    ':image' => $imagePath,
    ':id' => $id
  ]);

  header("Location: service.php");
  exit();
}

function synchroniserImage($imagePath)
{
  $filename = basename($imagePath);
  $adminPath = __DIR__ . '/img/' . $filename;
  $clientPath = __DIR__ . '/../supercar/img/' . $filename;

  if (file_exists($adminPath)) {
    if (!copy($adminPath, $clientPath)) {
      echo "Erreur lors de la synchronisation de l'image.";
    }
  }
}
?>

<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Modifier le Service</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700;900&display=swap" rel="stylesheet">

  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Roboto', sans-serif;

    }

    .container {
      width: 90%;
      margin-top: 3rem;
      max-width: 1000px;
      background-color: white;
      padding: 40px;
      border-radius: 12px;
      border: 2px solid #8e1616;
      box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      color: #8e1616;
      margin-bottom: 30px;
    }

    .form-label {
      font-weight: bold;
      margin-top: 15px;
    }

    .form-control {
      margin-bottom: 20px;
      padding: 10px;
      font-size: 16px;
    }

    .btn-primary {
      background-color: #8e1616;
      border: none;
      color: white;
      padding: 12px 20px;
      cursor: pointer;
      width: 100%;
      font-size: 16px;
      margin-top: 10px;
    }

    .btn-dark{
      width: 100%;
    }

    
    .btn-primary:hover {
      background-color: #6e1010;
    }

    img.img-thumbnail {
      max-width: 300px;
      height: auto;
      border-radius: 5px;
      margin-bottom: 20px;
      display: block;
    }

    @media (max-width: 576px) {
      .container {
        padding: 20px;
      }

      img.img-thumbnail {
        max-width: 100%;
      }
    }
  </style>

</head>

<body>

  <div class="container">
    <h1>Modifier le Service</h1>
    <form method="POST" enctype="multipart/form-data">
      <label class="form-label">Nom du Service</label>
      <input type="text" class="form-control" name="service" value="<?= htmlspecialchars($service['service']) ?>" required>

      <label class="form-label">Titre</label>
      <input type="text" class="form-control" name="title" value="<?= htmlspecialchars($service['title']) ?>" required>

      <label class="form-label">Description</label>
      <textarea class="form-control" name="description" rows="5" required><?= htmlspecialchars($service['description']) ?></textarea>

      <label class="form-label">Image actuelle</label><br>
      <img src="<?= $service['image'] ?>" alt="Image actuelle" class="img-thumbnail">

      <label class="form-label">Nouvelle image</label>
      <input type="file" class="form-control" name="image">

      <div class="btn-ctn">
      <button type="submit" class="btn btn-primary mt-3">Enregistrer</button>
      <a href=""><button type="submit" class="btn btn-dark mt-3">Retour</button></a>
      </div>
      
       

    </form>
  </div>

</body>

</html>