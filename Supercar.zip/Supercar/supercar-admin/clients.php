<?php
include 'config/config.php';
include 'includes/navbar.php';

// Récupération des clients
$sqlClientsData = "SELECT id_client, nom_client, prenom_client, email_client, telephone_client, adresse_client FROM client";
$resultClientsData = $pdo->query($sqlClientsData);
$clients = $resultClientsData->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Liste des Clients</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <style> 
    .btn-custom {
      background-color: #8E1616;
      text-decoration: none;
        color: white;
        border: none;
        padding: 10px 20px;
        transition: background-color 0.3s ease;
        font-weight: 500;
        border-radius: 5px;
        
    }
  </style>
 
   
</head>
<body>
  <div class="container mt-5">
    <h2 class="text-center mb-4">Liste des Clients</h2>
    <div class="table-responsive">
      <table class="table table-bordered table-striped">
        <thead>
          <tr>
            <th>ID</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Email</th>
            <th>Téléphone</th>
            <th>Adresse</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($clients as $client): ?>
            <tr>
              <td data-label="ID"><?= $client['id_client']; ?></td>
              <td data-label="Nom"><?= $client['nom_client']; ?></td>
              <td data-label="Prénom"><?= $client['prenom_client']; ?></td>
              <td data-label="Email"><?= $client['email_client']; ?></td>
              <td data-label="Téléphone"><?= $client['telephone_client']; ?></td>
              <td data-label="Adresse"><?= $client['adresse_client']; ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="container mt-3 clients">
      <a href="dashboard.php" class="btn-custom">Retourner au tableau de bord</a>
    </div>
  </div>
    
  

</body>
</html>
